-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Servidor: mysql.laskeysdelplus.com
-- Tiempo de generación: 09-03-2013 a las 12:52:39
-- Versión del servidor: 5.1.53
-- Versión de PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `solidstate`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('Individual Account','Business Account') NOT NULL DEFAULT 'Business Account',
  `status` enum('Active','Inactive','Pending') NOT NULL DEFAULT 'Active',
  `billingstatus` enum('Bill','Do Not Bill') NOT NULL DEFAULT 'Bill',
  `billingday` int(11) NOT NULL DEFAULT '0',
  `businessname` varchar(255) DEFAULT NULL,
  `contactname` varchar(255) NOT NULL DEFAULT '',
  `contactemail` varchar(255) NOT NULL DEFAULT '',
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `postalcode` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mobilephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `account`
--

INSERT INTO `account` (`id`, `type`, `status`, `billingstatus`, `billingday`, `businessname`, `contactname`, `contactemail`, `address1`, `address2`, `city`, `state`, `country`, `postalcode`, `phone`, `mobilephone`, `fax`) VALUES
(1, 'Business Account', 'Active', 'Bill', 1, 'Grupo Creacion', 'Juan Jesï¿½s Acevedo', 'volga.juanje@gmail.com', 'Campoamor, 10', 'Can Parellada', 'Masquefa', 'Barcelona', 'ES', '8783', '34-93-7789942', '', ''),
(2, 'Individual Account', 'Active', 'Bill', 20, 'Acuchilladores Bilbao', 'Oscar  Linares Carrascosa', 'oscheres@hotmail.com', 'AV SAN BARTOLOME N -9 PISO 19-E', '', 'Barakaldo', 'Vizcaia', 'ES', '48903', '34-660-444580', '', ''),
(3, 'Business Account', 'Active', 'Bill', 1, 'Jaramar', 'Estudios y Proyectos Jaramar S.L.', 'jaramar@jaramar.eu', 'Calle Olivas, 25', '', 'Brunete', 'Madrid', 'ES', '28690+', '34-91-8158092', '', ''),
(4, 'Individual Account', 'Pending', 'Bill', 1, 'Francesc Villalba Bonillo', 'Francesc Villalba Bonillo', 'francesc.villalba@db.com', '???', '', '???', '???', 'ES', '???', '1-555-5555', '', ''),
(5, 'Individual Account', 'Pending', 'Do Not Bill', 1, 'jose luis cabezas besa', 'jose luis cabezas besa', 'gautxorin@msn.com', '-', '', '-', '-', 'ES', '-', '34-999-999999', '', ''),
(6, 'Individual Account', 'Pending', 'Do Not Bill', 1, 'Ana Subiza', 'Ana Subiza', 'asubiza@yahoo.es', '-', '', '-', '-', 'ES', '-', '34-999-999999', '', ''),
(7, 'Individual Account', 'Pending', 'Do Not Bill', 1, 'jose luis cabezas besa', 'jose luis cabezas besa', 'gautxorin@msn.com', '-', '', '-', '-', 'ES', '0', '34-000-000000', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `authorizeaim`
--

CREATE TABLE IF NOT EXISTS `authorizeaim` (
  `transid` varchar(10) NOT NULL,
  `lastdigits` varchar(4) NOT NULL,
  PRIMARY KEY (`transid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `authorizeaim`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `batch`
--

CREATE TABLE IF NOT EXISTS `batch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `batch`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billing`
--

CREATE TABLE IF NOT EXISTS `billing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `company` varchar(100) DEFAULT NULL,
  `street` varchar(100) NOT NULL DEFAULT '',
  `city` varchar(100) NOT NULL DEFAULT '',
  `state` char(3) NOT NULL DEFAULT '',
  `country` varchar(100) NOT NULL DEFAULT 'USA',
  `zip` varchar(20) NOT NULL DEFAULT '',
  `phone` varchar(20) NOT NULL DEFAULT '',
  `fax` varchar(20) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `account_number` int(11) NOT NULL DEFAULT '0',
  `billing_type` int(11) NOT NULL DEFAULT '0',
  `creditcard_number` varchar(16) DEFAULT NULL,
  `creditcard_expire` smallint(4) unsigned zerofill DEFAULT NULL,
  `billing_status` int(11) NOT NULL DEFAULT '0',
  `disable_billing` enum('y','n') DEFAULT NULL,
  `next_billing_date` date NOT NULL DEFAULT '0000-00-00',
  `prev_billing_date` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `payment_due_date` date DEFAULT NULL,
  `rerun_date` date DEFAULT NULL,
  `notes` text,
  `pastdue_exempt` enum('y','n','bad_debt') NOT NULL DEFAULT 'n',
  `po_number` varchar(64) DEFAULT NULL,
  `organization_id` int(11) NOT NULL DEFAULT '1',
  `encrypted_creditcard_number` text,
  `automatic_receipt` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Volcar la base de datos para la tabla `billing`
--

INSERT INTO `billing` (`id`, `name`, `company`, `street`, `city`, `state`, `country`, `zip`, `phone`, `fax`, `contact_email`, `account_number`, `billing_type`, `creditcard_number`, `creditcard_expire`, `billing_status`, `disable_billing`, `next_billing_date`, `prev_billing_date`, `from_date`, `to_date`, `payment_due_date`, `rerun_date`, `notes`, `pastdue_exempt`, `po_number`, `organization_id`, `encrypted_creditcard_number`, `automatic_receipt`) VALUES
(1, 'Example Customer', 'Example Company', 'Example St', 'ExampleCity', 'ABC', 'USA', '12345', '555-555-5555', '555-555-5556', '', 1, 7, '5***********0001', 0909, 0, NULL, '2007-10-07', NULL, '2007-10-07', '2007-11-07', '2007-10-07', NULL, '', 'n', '', 1, '-----BEGIN PGP MESSAGE-----\nVersion: GnuPG v1.4.6 (GNU/Linux)\n\nhQIOA5EpLKAGbJnoEAgAiE78z7h8Cwv3j13JgEnA1mS1NJt4/wC88U7bydZjZX5F\nHPIp89SFlF1OwzTQlJ3Gke3/oVLRQMi5Tg1GMDdTcyon5yqz4Ay7gdO66du21HhA\nVqZYheytSCMbw8mfiHIWj1p0ou4hfhhutk4zbAtlQrHzq6taLL68pSUOcOZskq8Y\nM5MeDZJ+KpIwzuxeEvSWftlxrKT2FL9sOwOB+kGo5j8Ot5wxh/6xckYNdPJiZRuG\n4rZFqwr0X2ybNOoTEhOi65fMpg9ksSTKNvlV82fZmZN6pJhhBwZhEMUUmM/1QYGJ\nNU8N8WhaGNYrnERF4shWR5ctgu9Ke7kOVLarTvoMtQf+LwxeAMV7v7An+0gddF+v\nnUjaZmKB0DdEIXcCyj5vBVTzo6ArwzmIOhOC7eoe8D4nXNrLHsyKHWUt8aEAhCjJ\nurjRePyCqZUUN7lBsoYfMBQugr0myHm8ZqEk6UBEAvmVq4MSoVl3sAeBFJcmss7t\nPweyHbFCZbRwUcExGUaG3xHdCdb29JE3rPD4a3cMLFPecQlmPWHXNNlPHdGVltVF\nOg6pYJ2TUr4eXGIuJr/AKp8snWcx2N3wZVRsEnP9FH2RIvZ+j6b19Ugi/FAC9Qvj\n9G2/cX9a6CQ0vwwciOg7FcjiuTNntwecuatOdTh8lWiiwVlBuTU27h8tu/t5FIFh\nedJBAXY+/vwEoyFKjbXsnU5v6W9mRA6yUSeszxIQ26xfftbd1zyAmUgHwTBmQ3yB\ndhHZ87glQiWZ33rj8fB1SIITABs=\n=Rift\n-----END PGP MESSAGE-----', 'n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billing_details`
--

CREATE TABLE IF NOT EXISTS `billing_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `billing_id` int(11) NOT NULL DEFAULT '0',
  `creation_date` date NOT NULL DEFAULT '0000-00-00',
  `user_services_id` int(11) DEFAULT NULL,
  `taxed_services_id` int(11) DEFAULT NULL,
  `invoice_number` int(11) DEFAULT NULL,
  `billed_amount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `batch` int(11) NOT NULL DEFAULT '0',
  `refund_amount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `refunded` enum('y','n') NOT NULL DEFAULT 'n',
  `refund_date` date DEFAULT NULL,
  `rerun` enum('y','n') DEFAULT 'n',
  `rerun_date` date DEFAULT NULL,
  `payment_applied` date DEFAULT NULL,
  `original_invoice_number` int(11) DEFAULT NULL,
  `payment_history_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date` (`creation_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `billing_details`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billing_history`
--

CREATE TABLE IF NOT EXISTS `billing_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `billing_date` date NOT NULL DEFAULT '0000-00-00',
  `created_by` varchar(32) NOT NULL DEFAULT 'citrus',
  `record_type` set('bill','payment') DEFAULT NULL,
  `billing_type` set('creditcard','invoice','einvoice','prepay','prepaycc','free') NOT NULL DEFAULT '',
  `billing_id` int(11) NOT NULL DEFAULT '0',
  `from_date` date DEFAULT '0000-00-00',
  `to_date` date DEFAULT '0000-00-00',
  `payment_due_date` date DEFAULT NULL,
  `details` varchar(32) DEFAULT NULL,
  `new_charges` decimal(9,2) NOT NULL DEFAULT '0.00',
  `past_due` decimal(9,2) DEFAULT '0.00',
  `late_fee` decimal(9,2) NOT NULL DEFAULT '0.00',
  `tax_due` decimal(9,2) NOT NULL DEFAULT '0.00',
  `total_due` decimal(9,2) NOT NULL DEFAULT '0.00',
  `notes` text,
  `credit_applied` decimal(9,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `billing_history`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billing_types`
--

CREATE TABLE IF NOT EXISTS `billing_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `frequency` int(11) NOT NULL DEFAULT '1',
  `method` enum('creditcard','invoice','einvoice','prepay','prepaycc','free') NOT NULL DEFAULT 'creditcard',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Volcar la base de datos para la tabla `billing_types`
--

INSERT INTO `billing_types` (`id`, `name`, `frequency`, `method`) VALUES
(1, 'CreditCard Monthly', 1, 'creditcard'),
(7, 'Invoice Monthly', 1, 'invoice'),
(4, 'CreditCard 6 Months', 6, 'creditcard'),
(6, 'CreditCard 1 Year', 12, 'creditcard'),
(8, 'Invoice Quarterly', 3, 'invoice'),
(9, 'Invoice 6 Months', 6, 'invoice'),
(10, 'Invoice Yearly', 12, 'invoice'),
(13, 'Prepay 6 Months', 6, 'prepay'),
(15, 'Prepay 1 Year', 12, 'prepay'),
(16, 'Free', 0, 'free'),
(18, 'Prepay 2 Years', 24, 'prepay'),
(25, 'Prepay CreditCard 6 Months', 6, 'prepaycc'),
(26, 'Prepay CreditCard 1 Year', 12, 'prepaycc'),
(32, 'E-Invoice Monthly', 1, 'einvoice'),
(33, 'E-Invoice 6 Months', 6, 'einvoice'),
(34, 'E-Invoice Yearly', 12, 'einvoice');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `businessname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `address3` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `postalcode` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mobilephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Volcar la base de datos para la tabla `contact`
--

INSERT INTO `contact` (`id`, `name`, `businessname`, `email`, `address1`, `address2`, `address3`, `city`, `state`, `country`, `postalcode`, `phone`, `mobilephone`, `fax`) VALUES
(1, 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', '', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'ES', '1212', '34-333-333333', '', ''),
(2, 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', '', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'ES', '1212', '34-333-333333', '', ''),
(3, 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', '', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'ES', '1212', '34-333-333333', '', ''),
(4, 'miempresa', 'miempresa', 'miempresa@pepe.com', 'miempresa', 'miempresa', 'miempresa', 'miempresa', 'miempresa', 'TW', '333333', '34-333-333333', '', ''),
(5, 'miempresa', 'miempresa', 'miempresa@pepe.com', 'miempresa', 'miempresa', 'miempresa', 'miempresa', 'miempresa', 'TW', '333333', '34-333-333333', '', ''),
(6, 'miempresa', 'miempresa', 'miempresa@pepe.com', 'miempresa', 'miempresa', 'miempresa', 'miempresa', 'miempresa', 'TW', '333333', '34-333-333333', '', ''),
(7, 'Keys', '', 'keys.plus@gmail.com', 'Plus s/n', '', '', 'Ninguna', 'Provincia', 'ES', '8080', '34-123-456789', '', ''),
(8, 'Keys', '', 'keys.plus@gmail.com', 'Plus s/n', '', '', 'Ninguna', 'Provincia', 'ES', '8080', '34-123-456789', '', ''),
(9, 'Keys', '', 'keys.plus@gmail.com', 'Plus s/n', '', '', 'Ninguna', 'Provincia', 'ES', '8080', '34-123-456789', '', ''),
(10, 'Mi Nombre', 'Mi Empresa', 'sistemas@webhouse.es', 'Mi direcciÃ³n', '', '', 'Mi Ciudad', 'Mi Provincia', 'ES', '0', '34-91-3151212', '', ''),
(11, 'Mi Nombre', 'Mi Empresa', 'sistemas@webhouse.es', 'Mi direcciÃ³n', '', '', 'Mi Ciudad', 'Mi Provincia', 'ES', '0', '34-91-3151212', '', ''),
(12, 'Mi Nombre', 'Mi Empresa', 'sistemas@webhouse.es', 'Mi direcciÃ³n', '', '', 'Mi Ciudad', 'Mi Provincia', 'ES', '0', '34-91-3151212', '', ''),
(13, 'FRANCISCO SALINAS', 'SOCIEDAD VALENCIANA DE EXPLOTACIONES VARIAS SL', 'gmccombustibles@gmail.com', 'GUILLEM DE ASTRO,13-4Âª', '', '', 'VALENCIA', 'ESPAÃ‘A', 'ES', '46007', '34-96-3510206', '', ''),
(14, 'FRANCISCO SALINAS', 'SOCIEDAD VALENCIANA DE EXPLOTACIONES VARIAS SL', 'gmccombustibles@gmail.com', 'GUILLEM DE ASTRO,13-4Âª', '', '', 'VALENCIA', 'ESPAÃ‘A', 'ES', '46007', '34-96-3510206', '', ''),
(15, 'FRANCISCO SALINAS', 'SOCIEDAD VALENCIANA DE EXPLOTACIONES VARIAS SL', 'gmccombustibles@gmail.com', 'GUILLEM DE ASTRO,13-4Âª', '', '', 'VALENCIA', 'ESPAÃ‘A', 'ES', '46007', '34-96-3510206', '', ''),
(16, 'FRANCISCO SALINAS', 'SOCIEDAD VALENCIANA DE EXPLOTACIONES VARIAS SL', 'gmccombustibles@gmail.com', 'GUILLEM DE ASTRO,13-4Âª', '', '', 'VALENCIA', 'ESPAÃ‘A', 'ES', '46007', '34-96-3510206', '', ''),
(17, 'FRANCISCO SALINAS', 'SOCIEDAD VALENCIANA DE EXPLOTACIONES VARIAS SL', 'gmccombustibles@gmail.com', 'GUILLEM DE ASTRO,13-4Âª', '', '', 'VALENCIA', 'ESPAÃ‘A', 'ES', '46007', '34-96-3510206', '', ''),
(18, 'FRANCISCO SALINAS', 'SOCIEDAD VALENCIANA DE EXPLOTACIONES VARIAS SL', 'gmccombustibles@gmail.com', 'GUILLEM DE ASTRO,13-4Âª', '', '', 'VALENCIA', 'ESPAÃ‘A', 'ES', '46007', '34-96-3510206', '', ''),
(19, 'sdasdasd', 'dasdasda', 'jaceved2@xtec.cat', 'asdasdasdas', 'dsdasd', '', 'dasdasd', 'asdasdas', 'PM', 'dasdasd', '34-323-234234234', '', ''),
(20, 'sdasdasd', 'dasdasda', 'jaceved2@xtec.cat', 'asdasdasdas', 'dsdasd', '', 'dasdasd', 'asdasdas', 'PM', 'dasdasd', '34-323-234234234', '', ''),
(21, 'sdasdasd', 'dasdasda', 'jaceved2@xtec.cat', 'asdasdasdas', 'dsdasd', '', 'dasdasd', 'asdasdas', 'PM', 'dasdasd', '34-323-234234234', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cpanelserver`
--

CREATE TABLE IF NOT EXISTS `cpanelserver` (
  `serverid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `accesshash` text NOT NULL,
  PRIMARY KEY (`serverid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `cpanelserver`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `credit_options`
--

CREATE TABLE IF NOT EXISTS `credit_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_services` int(11) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `credit_options`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `source` varchar(100) DEFAULT NULL,
  `signup_date` date NOT NULL DEFAULT '0000-00-00',
  `name` varchar(255) NOT NULL DEFAULT '',
  `company` varchar(255) DEFAULT NULL,
  `street` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` char(3) NOT NULL DEFAULT '',
  `country` varchar(255) NOT NULL DEFAULT 'USA',
  `zip` varchar(20) NOT NULL DEFAULT '',
  `phone` varchar(20) NOT NULL DEFAULT '',
  `alt_phone` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `account_number` int(11) NOT NULL AUTO_INCREMENT,
  `secret_question` varchar(254) DEFAULT NULL,
  `secret_answer` varchar(100) DEFAULT NULL,
  `cancel_date` date DEFAULT NULL,
  `removal_date` date DEFAULT NULL,
  `default_billing_id` int(10) unsigned NOT NULL DEFAULT '0',
  `account_manager_password` varchar(32) DEFAULT NULL,
  `cancel_reason` int(11) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`account_number`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10000 ;

--
-- Volcar la base de datos para la tabla `customer`
--

INSERT INTO `customer` (`source`, `signup_date`, `name`, `company`, `street`, `city`, `state`, `country`, `zip`, `phone`, `alt_phone`, `fax`, `contact_email`, `account_number`, `secret_question`, `secret_answer`, `cancel_date`, `removal_date`, `default_billing_id`, `account_manager_password`, `cancel_reason`, `notes`) VALUES
('example', '2005-09-25', 'Example Customer', 'Example Company', 'Example St', 'ExampleCity', 'MAC', 'USA', '12345', '555-555-5555', '555-666-7777', '555-555-5556', 'example@example.com', 1, 'what question?', 'secret', NULL, NULL, 1, 'test', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_history`
--

CREATE TABLE IF NOT EXISTS `customer_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` varchar(20) NOT NULL DEFAULT 'citrus',
  `notify` varchar(32) NOT NULL DEFAULT '',
  `account_number` int(11) NOT NULL DEFAULT '0',
  `status` enum('automatic','not done','pending','completed') NOT NULL DEFAULT 'automatic',
  `description` text NOT NULL,
  `linkurl` varchar(255) DEFAULT NULL,
  `linkname` varchar(64) DEFAULT NULL,
  `user_services_id` int(11) DEFAULT NULL,
  `closed_by` varchar(64) DEFAULT NULL,
  `closed_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `customer_history`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `domainservice`
--

CREATE TABLE IF NOT EXISTS `domainservice` (
  `tld` varchar(255) NOT NULL DEFAULT '',
  `modulename` varchar(255) DEFAULT NULL,
  `description` blob,
  `price1yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price2yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price3yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price4yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price5yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price6yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price7yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price8yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price9yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price10yr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `taxable` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`tld`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `domainservice`
--

INSERT INTO `domainservice` (`tld`, `modulename`, `description`, `price1yr`, `price2yr`, `price3yr`, `price4yr`, `price5yr`, `price6yr`, `price7yr`, `price8yr`, `price9yr`, `price10yr`, `taxable`) VALUES
('com', 'nullregistrar', 0x446f6d696e696f202e434f4d, 25.00, 50.00, 75.00, 100.00, 125.00, 150.00, 175.00, 200.00, 225.00, 250.00, 'Yes'),
('es', 'nullregistrar', 0x446f6d696e696f202e4553, 25.00, 50.00, 75.00, 100.00, 125.00, 150.00, 175.00, 200.00, 225.00, 250.00, 'Yes'),
('eu', 'nullregistrar', 0x446f6d696e696f202e4555, 25.00, 50.00, 75.00, 100.00, 125.00, 150.00, 175.00, 200.00, 225.00, 250.00, 'Yes'),
('net', 'nullregistrar', 0x446f6d696e696f202e4e4554, 25.00, 50.00, 75.00, 100.00, 125.00, 150.00, 175.00, 200.00, 225.00, 250.00, 'Yes'),
('org', 'nullregistrar', 0x446f6d696e696f202e4f5247, 25.00, 50.00, 75.00, 100.00, 125.00, 150.00, 175.00, 200.00, 225.00, 250.00, 'Yes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `domainserviceprice`
--

CREATE TABLE IF NOT EXISTS `domainserviceprice` (
  `tld` varchar(255) NOT NULL DEFAULT '',
  `type` enum('Onetime','Recurring') NOT NULL DEFAULT 'Onetime',
  `termlength` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(20,2) NOT NULL DEFAULT '0.00',
  `taxable` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`tld`,`type`,`termlength`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `domainserviceprice`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `domainservicepurchase`
--

CREATE TABLE IF NOT EXISTS `domainservicepurchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` int(11) NOT NULL DEFAULT '0',
  `tld` varchar(255) NOT NULL DEFAULT '',
  `term` enum('1 year','2 year','3 year','4 year','5 year','6 year','7 year','8 year','9 year','10 year') NOT NULL DEFAULT '1 year',
  `domainname` varchar(255) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expiredate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `accountname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `domainservicepurchase`
--

INSERT INTO `domainservicepurchase` (`id`, `accountid`, `tld`, `term`, `domainname`, `date`, `expiredate`, `accountname`) VALUES
(1, 1, 'com', '1 year', 'creacionpaginasweb', '2005-09-19 00:00:01', '2006-09-19 00:00:01', 'Grupo Creación'),
(2, 2, 'com', '1 year', 'acuchilladoresbilbao', '2007-06-20 00:00:01', '2008-06-20 00:00:01', 'Oscar  Linares Carrascosa'),
(4, 4, 'com', '1 year', 'dominio', '2007-03-31 00:00:01', '2008-03-31 00:00:01', 'Francesc Villalba Bonillo'),
(5, 6, 'com', '1 year', 'dominio', '2007-04-20 00:00:01', '2008-04-20 00:00:01', 'Ana Subiza'),
(6, 7, 'com', '1 year', 'dominio', '2007-04-21 00:00:01', '2008-04-21 00:00:01', 'jose luis cabezas besa'),
(8, 2, 'com', '1 year', 'acuchilladoresvitoria', '2007-07-15 00:00:01', '2008-07-15 00:00:01', 'Oscar  Linares Carrascosa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `example_options`
--

CREATE TABLE IF NOT EXISTS `example_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_services` int(11) NOT NULL DEFAULT '0',
  `username` varchar(12) DEFAULT NULL,
  `password` varchar(12) DEFAULT NULL,
  `operating_system` enum('Windows 9x','WindowsNT/2K/XP','Mac OS 9','Mac OS X','Linux') DEFAULT NULL,
  `service_address` varchar(128) DEFAULT NULL,
  `equipment` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `example_options`
--

INSERT INTO `example_options` (`id`, `user_services`, `username`, `password`, `operating_system`, `service_address`, `equipment`) VALUES
(1, 40, 'myname', 'mypass', 'Linux', '123 Main St.', 'equipment');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `general`
--

CREATE TABLE IF NOT EXISTS `general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_name` varchar(32) NOT NULL DEFAULT '',
  `org_street` varchar(32) NOT NULL DEFAULT '',
  `org_city` varchar(32) NOT NULL DEFAULT '',
  `org_state` varchar(32) NOT NULL DEFAULT '',
  `org_zip` varchar(32) NOT NULL DEFAULT '',
  `org_country` varchar(32) NOT NULL DEFAULT 'USA',
  `phone_sales` varchar(32) DEFAULT NULL,
  `email_sales` varchar(128) DEFAULT NULL,
  `phone_billing` varchar(32) DEFAULT NULL,
  `email_billing` varchar(128) DEFAULT NULL,
  `phone_custsvc` varchar(32) DEFAULT NULL,
  `email_custsvc` varchar(128) DEFAULT NULL,
  `ccexportvarorder` varchar(255) NOT NULL DEFAULT '$mybilling_id,$invoice_number,$billing_ccnum,$billing_ccexp,$abstotal,$billing_zip,$billing_street',
  `regular_pastdue` int(11) NOT NULL DEFAULT '0',
  `regular_turnoff` int(11) NOT NULL DEFAULT '0',
  `regular_canceled` int(11) NOT NULL DEFAULT '0',
  `default_invoicenote` varchar(255) DEFAULT NULL,
  `pastdue_invoicenote` varchar(255) DEFAULT NULL,
  `turnedoff_invoicenote` varchar(255) DEFAULT NULL,
  `collections_invoicenote` varchar(255) DEFAULT NULL,
  `declined_subject` varchar(64) DEFAULT NULL,
  `declined_message` text,
  `invoice_footer` text,
  `dependent_pastdue` int(11) NOT NULL DEFAULT '0',
  `dependent_shutoff_notice` int(11) NOT NULL DEFAULT '0',
  `dependent_turnoff` int(11) NOT NULL DEFAULT '0',
  `dependent_canceled` int(11) NOT NULL DEFAULT '0',
  `exportprefix` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `general`
--

INSERT INTO `general` (`id`, `org_name`, `org_street`, `org_city`, `org_state`, `org_zip`, `org_country`, `phone_sales`, `email_sales`, `phone_billing`, `email_billing`, `phone_custsvc`, `email_custsvc`, `ccexportvarorder`, `regular_pastdue`, `regular_turnoff`, `regular_canceled`, `default_invoicenote`, `pastdue_invoicenote`, `turnedoff_invoicenote`, `collections_invoicenote`, `declined_subject`, `declined_message`, `invoice_footer`, `dependent_pastdue`, `dependent_shutoff_notice`, `dependent_turnoff`, `dependent_canceled`, `exportprefix`) VALUES
(1, 'Citrus DB', '1 Citrus St.', 'Citrus City', 'Orange', '12346', 'USA', '123-456-7890', 'test@citrusdb.org', '617-555-5554', 'billing@citrusdb.org', '555-123456', 'customer@citrusdb.org', '$mybilling_id,$invoice_number,$billing_ccnum,$billing_ccexp,$abstotal,$billing_zip,$billing_street', 1, 14, 30, '', '', '', '', 'Billing Notice', 'Please contact COMPANY at 555-555-5555 concerning an issue billing your credit card.', '', 0, 0, 0, 0, 'citrus');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(50) NOT NULL DEFAULT '',
  `groupmember` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Volcar la base de datos para la tabla `groups`
--

INSERT INTO `groups` (`id`, `groupname`, `groupmember`) VALUES
(9, 'users', 'admin'),
(27, 'billing', 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `holiday`
--

CREATE TABLE IF NOT EXISTS `holiday` (
  `holiday_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`holiday_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `holiday`
--

INSERT INTO `holiday` (`holiday_date`) VALUES
('2006-01-01'),
('2006-05-29'),
('2006-07-04'),
('2006-09-04'),
('2006-11-23'),
('2006-12-25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hostingservice`
--

CREATE TABLE IF NOT EXISTS `hostingservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` blob,
  `setupprice1mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price1mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `setupprice3mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price3mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `setupprice6mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price6mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `setupprice12mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price12mo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `uniqueip` enum('Required','Not Required') NOT NULL DEFAULT 'Not Required',
  `taxable` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `hostingservice`
--

INSERT INTO `hostingservice` (`id`, `title`, `description`, `setupprice1mo`, `price1mo`, `setupprice3mo`, `price3mo`, `setupprice6mo`, `price6mo`, `setupprice12mo`, `price12mo`, `uniqueip`, `taxable`) VALUES
(1, 'Alojamiento Personal', 0x2a20313030204d42206573706163696f207765620d0a2a2032204742207472616e73666572656e636961206d656e7375616c0d0a2a2031302062757a6f6e657320646520636f7272656f20646520323530204d420d0a2a2031206375656e7461204654500d0a2a203130207265646972656363696f6e65730d0a2a20313020616c69617320646520636f7272656f, 14.70, 4.90, 9.80, 14.70, 4.90, 29.40, 0.00, 58.80, 'Not Required', 'Yes'),
(2, 'Alojamiento Profesional', 0x2a20333030204d42206573706163696f207765620d0a2a2034204742207472616e73666572656e636961206d656e7375616c0d0a2a2031352062757a6f6e657320646520636f7272656f0d0a2a2032206375656e746173204654500d0a2a2042617365206465206461746f73204d7953514c0d0a2a203135207265646972656363696f6e65730d0a2a20313520616c69617320646520636f7272656f, 26.85, 8.95, 17.90, 26.85, 8.95, 57.70, 0.00, 107.40, 'Not Required', 'Yes'),
(3, 'Alojamiento Empresarial', 0x2a2031303234204d42206573706163696f207765620d0a2a203130204742207472616e73666572656e636961206d656e7375616c0d0a2a2035302062757a6f6e657320646520636f7272656f0d0a2a2035206375656e746173204654500d0a2a2032204261736573206465206461746f73204d7953514c0d0a2a203530207265646972656363696f6e65730d0a2a20353020616c69617320646520636f7272656f, 59.85, 19.95, 39.90, 58.85, 19.95, 119.70, 0.00, 239.40, 'Not Required', 'Yes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hostingserviceprice`
--

CREATE TABLE IF NOT EXISTS `hostingserviceprice` (
  `serviceid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` enum('Onetime','Recurring') NOT NULL DEFAULT 'Onetime',
  `termlength` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(20,2) NOT NULL DEFAULT '0.00',
  `taxable` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`serviceid`,`type`,`termlength`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `hostingserviceprice`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hostingservicepurchase`
--

CREATE TABLE IF NOT EXISTS `hostingservicepurchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` int(11) NOT NULL DEFAULT '0',
  `hostingserviceid` int(11) NOT NULL DEFAULT '0',
  `serverid` int(11) DEFAULT NULL,
  `term` enum('1 month','3 month','6 month','12 month') NOT NULL DEFAULT '1 month',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `hostingservicepurchase`
--

INSERT INTO `hostingservicepurchase` (`id`, `accountid`, `hostingserviceid`, `serverid`, `term`, `date`) VALUES
(1, 2, 2, 0, '12 month', '2006-06-20 00:00:01'),
(2, 3, 2, 0, '12 month', '2007-03-09 00:00:01'),
(3, 1, 3, 0, '1 month', '2007-03-11 00:00:01'),
(4, 4, 3, 0, '12 month', '2007-03-31 00:00:01'),
(5, 6, 2, 0, '12 month', '2007-04-20 00:00:01'),
(7, 7, 2, 0, '12 month', '2007-04-21 00:00:01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `invoice`
--

CREATE TABLE IF NOT EXISTS `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `periodbegin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `periodend` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `note` blob,
  `terms` int(11) NOT NULL DEFAULT '1',
  `outstanding` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Volcar la base de datos para la tabla `invoice`
--

INSERT INTO `invoice` (`id`, `accountid`, `date`, `periodbegin`, `periodend`, `note`, `terms`, `outstanding`) VALUES
(6, 2, '2006-06-20 00:00:01', '2006-06-20 00:00:01', '2006-07-20 00:00:01', '', 365, 'no'),
(10, 4, '2007-03-31 00:00:01', '2007-03-31 00:00:01', '2007-05-01 00:00:01', '', 15, 'yes'),
(11, 6, '2007-04-20 00:00:01', '2007-04-20 00:00:01', '2007-05-20 00:00:01', '', 15, 'yes'),
(14, 7, '2007-04-21 00:00:01', '2007-04-21 00:00:01', '2007-05-21 00:00:01', '', 15, 'yes'),
(18, 2, '2007-06-20 00:00:01', '2007-06-20 00:00:01', '2007-07-20 00:00:01', '', 365, 'yes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `invoiceitem`
--

CREATE TABLE IF NOT EXISTS `invoiceitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL DEFAULT '0',
  `taxitem` enum('No','Yes') NOT NULL DEFAULT 'No',
  `quantity` int(11) DEFAULT NULL,
  `unitamount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `text` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

--
-- Volcar la base de datos para la tabla `invoiceitem`
--

INSERT INTO `invoiceitem` (`id`, `invoiceid`, `taxitem`, `quantity`, `unitamount`, `text`) VALUES
(6, 6, 'No', 1, 25.00, 'acuchilladoresbilbao.com'),
(5, 6, 'No', 1, 107.40, 'Alojamiento Profesional'),
(7, 6, 'No', 1, 480.00, 'DiseÃ±o web y programaciÃ³n'),
(33, 10, 'No', 1, 200.00, 'Instalaci&oacute;n de script'),
(34, 10, 'Yes', 1, 32.00, 'Instalaci&oacute;n de script: IVA @ 16.00%'),
(32, 10, 'Yes', 1, 40.00, 'DiseÃ±o BÃ¡sico: IVA @ 16.00%'),
(31, 10, 'No', 1, 250.00, 'DiseÃ±o BÃ¡sico'),
(29, 10, 'No', 1, 25.00, 'dominio.com'),
(30, 10, 'Yes', 1, 4.00, 'dominio.com: IVA @ 16.00%'),
(28, 10, 'Yes', 1, 38.30, 'Alojamiento Empresarial: IVA @ 16.00%'),
(27, 10, 'No', 1, 239.40, 'Alojamiento Empresarial'),
(35, 10, 'No', 1, 200.00, 'Instalaci&oacute;n de script'),
(36, 10, 'Yes', 1, 32.00, 'Instalaci&oacute;n de script: IVA @ 16.00%'),
(37, 11, 'No', 1, 107.40, 'Alojamiento Profesional'),
(38, 11, 'Yes', 1, 17.18, 'Alojamiento Profesional: IVA @ 16.00%'),
(39, 11, 'No', 1, 25.00, 'dominio.com'),
(40, 11, 'Yes', 1, 4.00, 'dominio.com: IVA @ 16.00%'),
(41, 11, 'No', 1, 618.75, 'Comercio ElectrÃ³nico'),
(42, 11, 'Yes', 1, 99.00, 'Comercio ElectrÃ³nico: IVA @ 16.00%'),
(68, 14, 'Yes', 1, 5.00, 'DiseÃ±o PÃ¡gina adicional: IVA @ 16.00%'),
(67, 14, 'No', 1, 31.25, 'DiseÃ±o PÃ¡gina adicional'),
(66, 14, 'Yes', 1, 40.00, 'DiseÃ±o BÃ¡sico: IVA @ 16.00%'),
(64, 14, 'Yes', 1, 4.00, 'dominio.com: IVA @ 16.00%'),
(65, 14, 'No', 1, 250.00, 'DiseÃ±o BÃ¡sico'),
(63, 14, 'No', 1, 25.00, 'dominio.com'),
(62, 14, 'Yes', 1, 17.18, 'Alojamiento Profesional: IVA @ 16.00%'),
(61, 14, 'No', 1, 107.40, 'Alojamiento Profesional'),
(72, 18, 'Yes', 1, 17.18, 'Alojamiento Profesional: IVA @ 16.00%'),
(71, 18, 'No', 1, 107.40, 'Alojamiento Profesional'),
(73, 18, 'No', 1, 25.00, 'acuchilladoresbilbao.com'),
(74, 18, 'Yes', 1, 4.00, 'acuchilladoresbilbao.com: IVA @ 16.00%');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ipaddress`
--

CREATE TABLE IF NOT EXISTS `ipaddress` (
  `ipaddress` int(11) NOT NULL DEFAULT '0',
  `serverid` int(11) NOT NULL DEFAULT '0',
  `purchaseid` int(11) DEFAULT NULL,
  PRIMARY KEY (`ipaddress`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `ipaddress`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `linked_services`
--

CREATE TABLE IF NOT EXISTS `linked_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `linkfrom` int(11) NOT NULL DEFAULT '0',
  `linkto` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `linked_services`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('notice','warning','error','critical','security') NOT NULL DEFAULT 'notice',
  `module` varchar(255) NOT NULL DEFAULT '',
  `text` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '0',
  `remoteip` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=403 ;

--
-- Volcar la base de datos para la tabla `log`
--

INSERT INTO `log` (`id`, `type`, `module`, `text`, `username`, `remoteip`, `date`) VALUES
(1, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 00:50:16'),
(2, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1473830506, '2007-03-09 01:24:22'),
(3, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 01:24:39'),
(4, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1473830506, '2007-03-09 01:25:22'),
(5, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 01:26:57'),
(6, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1473830506, '2007-03-09 01:31:26'),
(7, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 01:32:15'),
(8, 'notice', 'newaccountpage', 'New Account created', 'Administrador', 1473830506, '2007-03-09 02:15:11'),
(9, 'error', 'newdomainservicepage', 'Missing required field: Price (2 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(10, 'error', 'newdomainservicepage', 'Missing required field: Price (3 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(11, 'error', 'newdomainservicepage', 'Missing required field: Price (4 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(12, 'error', 'newdomainservicepage', 'Missing required field: Price (5 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(13, 'error', 'newdomainservicepage', 'Missing required field: Price (6 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(14, 'error', 'newdomainservicepage', 'Missing required field: Price (7 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(15, 'error', 'newdomainservicepage', 'Missing required field: Price (8 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(16, 'error', 'newdomainservicepage', 'Missing required field: Price (9 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:52'),
(17, 'error', 'newdomainservicepage', 'Missing required field: Price (10 No translation available for the given phrase_id: YEARS)', 'Administrador', 1473830506, '2007-03-09 02:24:51'),
(18, 'notice', 'editdomainservicepage', 'Changes saved to Domain Service', 'Administrador', 1473830506, '2007-03-09 02:25:50'),
(19, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1473830506, '2007-03-09 02:50:28'),
(20, 'security', 'Login', 'Login failed for Administrador', '', 1473830506, '2007-03-09 02:50:53'),
(21, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-03-09 02:50:53'),
(22, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 02:50:57'),
(23, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1473830506, '2007-03-09 02:52:32'),
(24, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 02:52:45'),
(25, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1473830506, '2007-03-09 02:54:44'),
(26, 'security', 'Login', 'Login failed for Administrador', '', 1473830506, '2007-03-09 02:55:05'),
(27, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-03-09 02:55:05'),
(28, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 02:55:11'),
(29, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1473830506, '2007-03-09 02:56:04'),
(30, 'security', 'Login', 'Login failed for Administrador', '', 1473830506, '2007-03-09 02:56:11'),
(31, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-03-09 02:56:11'),
(32, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-09 02:56:16'),
(33, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1473830506, '2007-03-09 02:56:33'),
(34, 'notice', 'editaccountpage', 'Account changes saved.', 'Administrador', 1473830506, '2007-03-09 02:59:08'),
(35, 'notice', 'assigndomainpage', 'Domain Service Added to Account', 'Administrador', 1473830506, '2007-03-09 03:01:17'),
(36, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1473830506, '2007-03-09 03:08:48'),
(37, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1473830506, '2007-03-09 03:08:55'),
(38, 'notice', 'newproductpage', 'Created new Product', 'Administrador', 1473830506, '2007-03-09 03:29:37'),
(39, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1473830506, '2007-03-09 04:37:04'),
(40, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1473830506, '2007-03-09 04:37:04'),
(41, 'notice', 'newproductpage', 'Created new Product', 'Administrador', 1473830506, '2007-03-09 04:38:14'),
(42, 'notice', 'newaccountpage', 'New Account created', 'Administrador', 1473830506, '2007-03-09 04:43:47'),
(43, 'notice', 'viewaccountpage', 'Note added.', 'Administrador', 1473830506, '2007-03-09 04:44:31'),
(44, 'notice', 'assigndomainpage', 'Domain Service Added to Account', 'Administrador', 1473830506, '2007-03-09 04:47:30'),
(45, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1473830506, '2007-03-09 05:08:15'),
(46, 'critical', 'CartPage::init()', 'No payment methods have been enabled.  The HSP must enable at least one payment method before the order interface can be used', '', 1042676305, '2007-03-09 07:41:22'),
(47, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-09 07:43:12'),
(48, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1042676305, '2007-03-09 08:05:53'),
(49, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-09 08:05:55'),
(50, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1042676305, '2007-03-09 08:06:33'),
(51, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-09 08:06:33'),
(52, 'notice', 'assignhostingpage', 'Hosting Service Added to Account', 'Administrador', 1042676305, '2007-03-09 08:08:10'),
(53, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-09 08:08:50'),
(54, 'notice', 'deleteinvoicepage', 'Invoice (ID: 1) Deleted', 'Administrador', 1042676305, '2007-03-09 08:09:19'),
(55, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-09 08:10:12'),
(56, 'notice', 'deleteinvoicepage', 'Invoice (ID: 2) Deleted', 'Administrador', 1042676305, '2007-03-09 08:10:31'),
(57, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-09 08:11:04'),
(58, 'notice', 'viewinvoicepage', 'Invoice Item added to Invoice', 'Administrador', 1042676305, '2007-03-09 08:11:19'),
(59, 'notice', 'viewinvoicepage', 'Invoice Item: \\"\\" removed from invoice.', 'Administrador', 1042676305, '2007-03-09 08:11:27'),
(60, 'notice', 'deleteinvoicepage', 'Invoice (ID: 3) Deleted', 'Administrador', 1042676305, '2007-03-09 08:11:45'),
(61, 'error', 'newaccountpage', 'Missing required field: Phone', 'Administrador', 1042676305, '2007-03-09 08:13:18'),
(62, 'notice', 'newaccountpage', 'New Account created', 'Administrador', 1042676305, '2007-03-09 08:15:50'),
(63, 'notice', 'assignhostingpage', 'Hosting Service Added to Account', 'Administrador', 1042676305, '2007-03-09 08:16:19'),
(64, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-09 08:22:11'),
(65, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-09 08:22:13'),
(66, 'notice', 'psmconfigpage', 'Paypal WPS Configuration Saved', 'Administrador', 1042676305, '2007-03-09 08:24:26'),
(67, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-09 08:24:39'),
(68, 'notice', 'configureedituserpage', 'User updated: Administrador', 'Administrador', 1042676305, '2007-03-09 08:25:34'),
(69, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-09 08:26:12'),
(70, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-09 08:26:27'),
(71, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-09 08:29:19'),
(72, 'critical', 'CustomerPage::init()', 'User account not found, account id = ', 'Administrador', 1042676305, '2007-03-09 08:32:00'),
(73, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-09 09:00:55'),
(74, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-09 09:01:41'),
(75, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1042676305, '2007-03-09 09:02:34'),
(76, 'error', 'adddomainpage', 'Missing required field: Domain Name', '', 1042676305, '2007-03-10 07:12:04'),
(77, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1042676305, '2007-03-10 07:12:04'),
(78, 'error', 'adddomainpage', 'Missing required field: Domain Name', '', 1042676305, '2007-03-10 07:12:10'),
(79, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1042676305, '2007-03-10 07:12:10'),
(80, 'error', 'adddomainpage', 'Missing required field: Domain Name', '', 1042676305, '2007-03-10 07:12:19'),
(81, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1042676305, '2007-03-10 07:12:19'),
(82, 'error', 'adddomainpage', 'Missing required field: Domain Name', '', 1042676305, '2007-03-10 07:12:22'),
(83, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1042676305, '2007-03-10 07:12:22'),
(84, 'error', 'customerpage', 'FRalta el campo requerido: Nombre', '', 1042676305, '2007-03-10 12:05:01'),
(85, 'error', 'customerpage', 'E-Mail requiere una direcciÃ³n de e-mmail vÃ¡lida', '', 1042676305, '2007-03-10 12:05:01'),
(86, 'error', 'customerpage', 'FRalta el campo requerido: Verificar E-mail', '', 1042676305, '2007-03-10 12:05:01'),
(87, 'error', 'customerpage', 'FRalta el campo requerido: DirecciÃ³n', '', 1042676305, '2007-03-10 12:05:01'),
(88, 'error', 'customerpage', 'FRalta el campo requerido: Ciudad', '', 1042676305, '2007-03-10 12:05:01'),
(89, 'error', 'customerpage', 'FRalta el campo requerido: Estado', '', 1042676305, '2007-03-10 12:05:01'),
(90, 'error', 'customerpage', 'FRalta el campo requerido: CÃ³digo Postal', '', 1042676305, '2007-03-10 12:05:01'),
(91, 'error', 'customerpage', 'FRalta el campo requerido: TelÃ©fonp', '', 1042676305, '2007-03-10 12:05:01'),
(92, 'error', 'customerpage', 'El lÃ­mite de tamaÃ±o (10) fuÃ© superado para el campo: Nombre de usuario', '', 1042676305, '2007-03-10 12:05:01'),
(93, 'error', 'customerpage', 'FRalta el campo requerido: Verificar ContraseÃ±a', '', 1042676305, '2007-03-10 12:05:01'),
(94, 'critical', 'customerloginpage', 'No page to jump back too!', '', 1042676305, '2007-03-10 12:08:54'),
(95, 'critical', 'customerloginpage', 'No page to jump back too!', '', 1042676305, '2007-03-10 12:09:01'),
(96, 'security', 'CustomerLoginPage::login()', 'Login failed for: jaramar', '', 1042676305, '2007-03-10 12:46:50'),
(97, 'error', 'customerloginpage', 'Ha fallado el ingreso.', '', 1042676305, '2007-03-10 12:46:48'),
(98, 'security', 'CustomerLoginPage::login()', 'Login failed for: jaramar', '', 1042676305, '2007-03-10 12:47:16'),
(99, 'error', 'customerloginpage', 'Ha fallado el ingreso.', '', 1042676305, '2007-03-10 12:47:16'),
(100, 'critical', 'customerloginpage', 'No page to jump back too!', '', 1042676305, '2007-03-10 13:24:53'),
(101, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-10 13:38:24'),
(102, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-10 13:38:47'),
(103, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-10 13:39:14'),
(104, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-10 13:39:20'),
(105, 'notice', 'editdomainservicepage', 'Changes saved to Domain Service', 'Administrador', 1042676305, '2007-03-10 13:41:35'),
(106, 'notice', 'editdomainservicepage', 'Changes saved to Domain Service', 'Administrador', 1042676305, '2007-03-10 13:42:05'),
(107, 'notice', 'registerdomainpage', ' ooo.com is available!', 'Administrador', 1042676305, '2007-03-10 13:45:36'),
(108, 'notice', 'registerdomainpage', ' ooo.com is available!', 'Administrador', 1042676305, '2007-03-10 13:45:49'),
(109, 'notice', 'registerdomainpage', 'microsoft.com is available!', 'Administrador', 1042676305, '2007-03-10 13:46:07'),
(110, 'notice', 'registerdomainpage', 'Sucessfuly registered microsoft.com.', 'Administrador', 1042676305, '2007-03-10 13:46:20'),
(111, 'notice', 'registerdomainpage', 'microsoft.com is available!', 'Administrador', 1042676305, '2007-03-10 13:46:39'),
(112, 'critical', 'editdomainpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-10 13:47:07'),
(113, 'notice', 'editdomainpage', 'Domain Renewed', 'Administrador', 1042676305, '2007-03-10 13:47:19'),
(114, 'critical', 'editdomainpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-10 13:47:19'),
(115, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-11 11:21:16'),
(116, 'notice', 'assignhostingpage', 'Hosting Service Added to Account', 'Administrador', 1042676305, '2007-03-11 11:22:39'),
(117, 'notice', 'viewaccountpage', 'Removed domain: microsoft.com', 'Administrador', 1042676305, '2007-03-11 11:22:48'),
(118, 'notice', 'deleteinvoicepage', 'Invoice (ID: 4) Deleted', 'Administrador', 1042676305, '2007-03-11 11:23:14'),
(119, 'error', 'billingpaymentpage', 'Missing required field: Invoice to Pay', 'Administrador', 1042676305, '2007-03-11 11:23:47'),
(120, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-11 11:24:31'),
(121, 'notice', 'viewinvoicepage', 'Invoice Item added to Invoice', 'Administrador', 1042676305, '2007-03-11 11:24:53'),
(122, 'notice', 'deleteinvoicepage', 'Invoice (ID: 5) Deleted', 'Administrador', 1042676305, '2007-03-11 11:25:06'),
(123, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-11 11:28:33'),
(124, 'notice', 'viewinvoicepage', 'Invoice Item added to Invoice', 'Administrador', 1042676305, '2007-03-11 11:33:30'),
(125, 'notice', 'addpaymentpage', 'Payment Received', 'Administrador', 1042676305, '2007-03-11 11:34:56'),
(126, 'notice', 'editdomainservicepage', 'Changes saved to Domain Service', 'Administrador', 1042676305, '2007-03-11 11:50:38'),
(127, 'notice', 'editdomainservicepage', 'Changes saved to Domain Service', 'Administrador', 1042676305, '2007-03-11 11:51:12'),
(128, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1042676305, '2007-03-11 11:51:56'),
(129, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-11 11:51:55'),
(130, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1042676305, '2007-03-11 11:53:01'),
(131, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-11 11:53:01'),
(132, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1042676305, '2007-03-11 11:55:41'),
(133, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-11 11:55:41'),
(134, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1042676305, '2007-03-11 11:56:58'),
(135, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-11 11:56:58'),
(136, 'notice', 'editproductpage', 'Changes saved to Product', 'Administrador', 1042676305, '2007-03-11 11:57:32'),
(137, 'critical', 'editproductpage', 'No page to jump back too!', 'Administrador', 1042676305, '2007-03-11 11:57:34'),
(138, 'notice', 'newproductpage', 'Created new Product', 'Administrador', 1042676305, '2007-03-11 11:58:54'),
(139, 'error', 'newproductpage', 'You must enter a number for field: Price', 'Administrador', 1042676305, '2007-03-11 12:00:09'),
(140, 'notice', 'newproductpage', 'Created new Product', 'Administrador', 1042676305, '2007-03-11 12:00:23'),
(141, 'notice', 'addtaxrulepage', 'Tax Rule Created.', 'Administrador', 1042676305, '2007-03-11 12:02:20'),
(142, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1042676305, '2007-03-11 12:02:53'),
(143, 'error', 'adddomainpage', 'FRalta el campo requerido: Domain Name', '', 1042676305, '2007-03-11 12:04:05'),
(144, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1042676305, '2007-03-11 12:04:05'),
(145, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-11 12:08:57'),
(146, 'critical', 'CustomerPage::init()', 'User account not found, account id = 0', 'Administrador', 1042676305, '2007-03-11 12:20:15'),
(147, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-11 12:23:17'),
(148, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-11 12:23:52'),
(149, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-11 12:23:59'),
(150, 'notice', 'psmconfigpage', 'Paypal WPS Configuration Saved', 'Administrador', 1042676305, '2007-03-11 12:30:28'),
(151, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-11 12:30:54'),
(152, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-11 12:30:58'),
(153, 'notice', 'psmconfigpage', 'Paypal WPS Configuration Saved', 'Administrador', 1042676305, '2007-03-11 12:31:14'),
(154, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1042676305, '2007-03-11 12:38:47'),
(155, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-11 12:38:53'),
(156, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-11 12:40:37'),
(157, 'notice', 'modulespage', 'Modules Updated.', 'Administrador', 1042676305, '2007-03-11 12:41:08'),
(158, 'notice', 'psmconfigpage', 'Paypal WPS Configuration Saved', 'Administrador', 1042676305, '2007-03-11 12:42:24'),
(159, 'notice', 'psmconfigpage', 'Paypal WPS Configuration Saved', 'Administrador', 1042676305, '2007-03-11 12:43:02'),
(160, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-11 12:43:16'),
(161, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-11 12:43:27'),
(162, 'critical', 'CustomerPage::init()', 'User account not found, account id = 0', 'Administrador', 1042676305, '2007-03-11 12:51:57'),
(163, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-11 12:58:56'),
(164, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-11 12:59:05'),
(165, 'notice', 'settingspage', 'Settings Saved.', 'Administrador', 1042676305, '2007-03-11 12:59:44'),
(166, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-11 13:44:33'),
(167, 'notice', 'vieworderpage', 'Order Deleted', 'Administrador', 1042676305, '2007-03-11 13:49:07'),
(168, 'notice', 'editaccountpage', 'Account changes saved.', 'Administrador', 1042676305, '2007-03-11 13:49:53'),
(169, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 1042676305, '2007-03-11 13:51:28'),
(170, 'error', 'adddomainpage', 'FRalta el campo requerido: Domain Name', '', 1473830506, '2007-03-12 07:51:05'),
(171, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1473830506, '2007-03-12 07:51:05'),
(172, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-12 08:06:43'),
(173, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-25 05:05:17'),
(174, 'notice', 'generateinvoicespage', 'Invoice Batch Completed.', 'Administrador', 1042676305, '2007-03-25 05:06:22'),
(175, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-25 05:06:31'),
(176, 'notice', 'viewinvoicepage', 'Invoice Item added to Invoice', 'Administrador', 1042676305, '2007-03-25 05:06:38'),
(177, 'notice', 'deleteinvoicepage', 'Invoice (ID: 7) Deleted', 'Administrador', 1042676305, '2007-03-25 05:06:47'),
(178, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-03-27 23:20:38'),
(179, 'notice', 'generateinvoicespage', 'Invoice Batch Completed.', 'Administrador', 1473830506, '2007-03-28 00:04:15'),
(180, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-03-31 05:58:21'),
(181, 'error', 'newaccountpage', 'Invalid Phone Number provided for Phone.  Please make sure you use no hyphens and only supply numeric digits.', 'Administrador', 1042676305, '2007-03-31 06:01:58'),
(182, 'notice', 'newaccountpage', 'New Account created', 'Administrador', 1042676305, '2007-03-31 06:02:12'),
(183, 'notice', 'assignhostingpage', 'Hosting Service Added to Account', 'Administrador', 1042676305, '2007-03-31 06:02:37'),
(184, 'notice', 'assigndomainpage', 'Domain Service Added to Account', 'Administrador', 1042676305, '2007-03-31 06:02:53'),
(185, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042676305, '2007-03-31 06:03:05'),
(186, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042676305, '2007-03-31 06:03:16'),
(187, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-31 06:03:46'),
(188, 'error', 'viewinvoicepage', 'Could not load Invoice! ID: ', 'Administrador', 1042676305, '2007-03-31 06:09:15'),
(189, 'critical', 'count_all_InvoiceItemDBO', 'SELECT COUNT failure', 'Administrador', 1042676305, '2007-03-31 06:09:15'),
(190, 'error', 'viewinvoicepage', 'Could not load Invoice! ID: ', 'Administrador', 1042676305, '2007-03-31 06:09:22'),
(191, 'critical', 'count_all_InvoiceItemDBO', 'SELECT COUNT failure', 'Administrador', 1042676305, '2007-03-31 06:09:22'),
(192, 'notice', 'deleteinvoicepage', 'Invoice (ID: 8) Deleted', 'Administrador', 1042676305, '2007-03-31 06:09:47'),
(193, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042676305, '2007-03-31 06:10:36'),
(194, 'notice', 'viewaccountpage', 'Removed product: Instalaci&oacute;n de script', 'Administrador', 1042676305, '2007-03-31 06:10:41'),
(195, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042676305, '2007-03-31 06:11:04'),
(196, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-31 06:11:18'),
(197, 'error', 'viewinvoicepage', 'Could not load Invoice! ID: ', 'Administrador', 1042676305, '2007-03-31 06:12:56'),
(198, 'notice', 'viewinvoicepage', 'Invoice Item: \\"DiseÃ±o BÃ¡sico\\" removed from invoice.', 'Administrador', 1042676305, '2007-03-31 06:12:56'),
(199, 'notice', 'deleteinvoicepage', 'Invoice (ID: 9) Deleted', 'Administrador', 1042676305, '2007-03-31 06:13:42'),
(200, 'notice', 'editaccountpage', 'Account changes saved.', 'Administrador', 1042676305, '2007-03-31 06:49:27'),
(201, 'notice', 'viewaccountpage', 'Removed product: DiseÃ±o BÃ¡sico', 'Administrador', 1042676305, '2007-03-31 06:49:40'),
(202, 'error', 'viewaccountpage', 'Account not found (id = )', 'Administrador', 1042676305, '2007-03-31 06:54:50'),
(203, 'critical', 'ViewAccountPage::deleteProduct()', 'could not find product purchase DBO', 'Administrador', 1042676305, '2007-03-31 06:54:50'),
(204, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042676305, '2007-03-31 06:55:28'),
(205, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-03-31 06:55:43'),
(206, 'error', 'customerpage', 'Falta el campo requerido: Nombre', '', -935782659, '2007-04-09 18:19:00'),
(207, 'error', 'customerpage', 'Falta el campo requerido: E-Mail', '', -935782659, '2007-04-09 18:19:00'),
(208, 'error', 'customerpage', 'Falta el campo requerido: Verificar E-mail', '', -935782659, '2007-04-09 18:19:00'),
(209, 'error', 'customerpage', 'Falta el campo requerido: DirecciÃ³n', '', -935782659, '2007-04-09 18:19:00'),
(210, 'error', 'customerpage', 'Falta el campo requerido: Ciudad', '', -935782659, '2007-04-09 18:19:00'),
(211, 'error', 'customerpage', 'Falta el campo requerido: Estado/Provincia', '', -935782659, '2007-04-09 18:19:00'),
(212, 'error', 'customerpage', 'Falta el campo requerido: CÃ³digo Postal', '', -935782659, '2007-04-09 18:19:00'),
(213, 'error', 'customerpage', 'Falta el campo requerido: TelÃ©fonp', '', -935782659, '2007-04-09 18:19:00'),
(214, 'error', 'customerpage', 'Falta el campo requerido: Nombre de usuario', '', -935782659, '2007-04-09 18:19:00'),
(215, 'error', 'customerpage', 'Falta el campo requerido: ContraseÃ±a', '', -935782659, '2007-04-09 18:19:00'),
(216, 'error', 'customerpage', 'Falta el campo requerido: Verificar ContraseÃ±a', '', -935782659, '2007-04-09 18:19:00'),
(217, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042676305, '2007-04-20 06:56:05'),
(218, 'notice', 'newaccountpage', 'New Account created', 'Administrador', 1042676305, '2007-04-20 07:14:02'),
(219, 'notice', 'viewaccountpage', 'Note added.', 'Administrador', 1042676305, '2007-04-20 07:14:24'),
(220, 'notice', 'newaccountpage', 'New Account created', 'Administrador', 1042676305, '2007-04-20 07:28:45'),
(221, 'notice', 'viewaccountpage', 'Note added.', 'Administrador', 1042676305, '2007-04-20 07:28:53'),
(222, 'notice', 'assignhostingpage', 'Hosting Service Added to Account', 'Administrador', 1042676305, '2007-04-20 07:30:32'),
(223, 'notice', 'assigndomainpage', 'Domain Service Added to Account', 'Administrador', 1042676305, '2007-04-20 07:32:34'),
(224, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042676305, '2007-04-20 07:32:52'),
(225, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042676305, '2007-04-20 07:33:03'),
(226, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1042663427, '2007-04-21 12:24:14'),
(227, 'notice', 'newaccountpage', 'New Account created', 'Administrador', 1042663427, '2007-04-21 12:25:20'),
(228, 'notice', 'viewaccountpage', 'Note added.', 'Administrador', 1042663427, '2007-04-21 12:25:31'),
(229, 'notice', 'viewaccountpage', 'Note added.', 'Administrador', 1042663427, '2007-04-21 12:26:03'),
(230, 'notice', 'assignhostingpage', 'Hosting Service Added to Account', 'Administrador', 1042663427, '2007-04-21 12:26:14'),
(231, 'notice', 'assigndomainpage', 'Domain Service Added to Account', 'Administrador', 1042663427, '2007-04-21 12:26:28'),
(232, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042663427, '2007-04-21 12:26:39'),
(233, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042663427, '2007-04-21 12:26:47'),
(234, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042663427, '2007-04-21 12:26:59'),
(235, 'error', 'viewinvoicepage', 'Could not load Invoice! ID: ', 'Administrador', 1042663427, '2007-04-21 12:29:36'),
(236, 'critical', 'count_all_InvoiceItemDBO', 'SELECT COUNT failure', 'Administrador', 1042663427, '2007-04-21 12:29:35'),
(237, 'notice', 'deleteinvoicepage', 'Invoice (ID: 12) Deleted', 'Administrador', 1042663427, '2007-04-21 12:31:23'),
(238, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042663427, '2007-04-21 12:32:21'),
(239, 'notice', 'deleteinvoicepage', 'Invoice (ID: 13) Deleted', 'Administrador', 1042663427, '2007-04-21 12:32:27'),
(240, 'notice', 'viewaccountpage', 'Removed hosting service: Alojamiento Profesional', 'Administrador', 1042663427, '2007-04-21 12:32:56'),
(241, 'notice', 'assignhostingpage', 'Hosting Service Added to Account', 'Administrador', 1042663427, '2007-04-21 12:33:06'),
(242, 'notice', 'viewaccountpage', 'Removed product: Instalaci&oacute;n de script', 'Administrador', 1042663427, '2007-04-21 12:33:20'),
(243, 'notice', 'assignproductpage', 'Product Added to Account', 'Administrador', 1042663427, '2007-04-21 12:33:33'),
(244, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1042663427, '2007-04-21 12:33:46'),
(245, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-04-24 00:34:10'),
(246, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1473830506, '2007-04-24 00:39:40'),
(247, 'notice', 'deleteinvoicepage', 'Invoice (ID: 15) Deleted', 'Administrador', 1473830506, '2007-04-24 00:40:13'),
(248, 'notice', 'editdomainpage', 'Domain Renewed', 'Administrador', 1473830506, '2007-04-24 00:43:33'),
(249, 'critical', 'editdomainpage', 'No page to jump back too!', 'Administrador', 1473830506, '2007-04-24 00:43:33'),
(250, 'notice', 'editdomainpage', 'Domain Renewed', 'Administrador', 1473830506, '2007-04-24 00:43:57'),
(251, 'critical', 'editdomainpage', 'No page to jump back too!', 'Administrador', 1473830506, '2007-04-24 00:43:57'),
(252, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1473830506, '2007-04-24 00:44:25'),
(253, 'notice', 'deleteinvoicepage', 'Invoice (ID: 16) Deleted', 'Administrador', 1473830506, '2007-04-24 00:44:38'),
(254, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1473830506, '2007-04-24 00:45:19'),
(255, 'notice', 'deleteinvoicepage', 'Invoice (ID: 17) Deleted', 'Administrador', 1473830506, '2007-04-24 00:45:27'),
(256, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 1473830506, '2007-04-24 00:45:57'),
(257, 'notice', 'emailinvoicepage', 'Invoice E-Mail sent.', 'Administrador', 1473830506, '2007-04-24 00:47:12'),
(258, 'security', 'Login', 'Login failed for admin', '', 1473830506, '2007-05-02 23:41:36'),
(259, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-02 23:41:36'),
(260, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-05-02 23:41:48'),
(261, 'security', 'Login', 'Login failed for admin', '', 1473830506, '2007-05-09 07:18:29'),
(262, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:18:29'),
(263, 'security', 'Login', 'Login failed for administrador', '', 1473830506, '2007-05-09 07:18:40'),
(264, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:18:40'),
(265, 'security', 'Login', 'Login failed for admin', '', 1473830506, '2007-05-09 07:18:46'),
(266, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:18:46'),
(267, 'security', 'Login', 'Login failed for admin', '', 1473830506, '2007-05-09 07:18:54'),
(268, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:18:54'),
(269, 'security', 'Login', 'Login failed for administrator', '', 1473830506, '2007-05-09 07:19:08'),
(270, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:19:08'),
(271, 'security', 'Login', 'Login failed for administrator', '', 1473830506, '2007-05-09 07:19:15'),
(272, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:19:15'),
(273, 'security', 'Login', 'Login failed for Administrator', '', 1473830506, '2007-05-09 07:19:24'),
(274, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:19:24'),
(275, 'security', 'Login', 'Login failed for Administrator', '', 1473830506, '2007-05-09 07:19:30'),
(276, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:19:30'),
(277, 'security', 'Login', 'Login failed for Administrador', '', 1473830506, '2007-05-09 07:19:38'),
(278, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-05-09 07:19:38'),
(279, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-05-09 07:19:45'),
(280, 'security', 'Login', 'Login failed for administrador', '', 1473830506, '2007-06-12 00:26:39'),
(281, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-06-12 00:26:39'),
(282, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-06-12 00:26:44'),
(283, 'error', 'adddomainpage', 'Falta el campo requerido: Domain Name', '', -931544112, '2007-07-14 14:39:48'),
(284, 'critical', 'adddomainpage', 'No page to jump back too!', '', -931544112, '2007-07-14 14:39:47'),
(285, 'security', 'Login', 'Login failed for admin', '', 1473830506, '2007-07-24 23:18:38'),
(286, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-07-24 23:18:38'),
(287, 'security', 'Login', 'Login failed for admin', '', 1473830506, '2007-07-24 23:18:43'),
(288, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-07-24 23:18:43'),
(289, 'security', 'Login', 'Login failed for administrador', '', 1473830506, '2007-07-24 23:18:49'),
(290, 'error', 'loginpage', 'Login Failed', '', 1473830506, '2007-07-24 23:18:49'),
(291, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1473830506, '2007-07-24 23:18:54'),
(292, 'error', 'adddomainpage', 'Falta el campo requerido: ', '', 1165439504, '2007-08-15 15:43:47'),
(293, 'error', 'adddomainpage', 'Falta el campo requerido: TLD', '', 1165439504, '2007-08-15 15:43:49'),
(294, 'error', 'adddomainpage', 'Falta el campo requerido: TLD', '', 1165439504, '2007-08-15 15:43:47'),
(295, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2007-11-14 06:41:37'),
(296, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2007-11-14 06:41:38'),
(297, 'error', 'adddomainpage', 'Falta el campo requerido: Domain Name', '', 1395092835, '2008-01-15 02:05:19'),
(298, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1395092835, '2008-01-15 02:05:21'),
(299, 'error', 'adddomainpage', 'Falta el campo requerido: Domain Name', '', 1395092835, '2008-01-15 02:17:04'),
(300, 'critical', 'adddomainpage', 'No page to jump back too!', '', 1395092835, '2008-01-15 02:17:04'),
(301, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-04-11 04:54:24'),
(302, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-04-11 04:54:25'),
(303, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-04-23 22:22:22'),
(304, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-04-23 22:22:23'),
(305, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-05-06 05:06:40'),
(306, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-05-06 05:06:40'),
(307, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-05-15 02:11:20'),
(308, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-05-15 02:11:20'),
(309, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-06-11 05:02:15'),
(310, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-06-11 05:02:16'),
(311, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-08-05 03:17:31'),
(312, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-08-05 03:17:30'),
(313, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-08-11 04:28:25'),
(314, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-08-11 04:28:25'),
(315, 'notice', 'PSIPNPage::init()', 'Processing an IPN...', '', 1121167938, '2008-11-13 09:08:26'),
(316, 'critical', 'PSIPNPage::init()', 'Failed to verify IPN', '', 1121167938, '2008-11-13 09:08:27'),
(317, 'error', 'customerpage', 'Falta el campo requerido: Nombre', '', -709844532, '2009-03-25 07:42:13'),
(318, 'error', 'customerpage', 'Falta el campo requerido: E-Mail', '', -709844532, '2009-03-25 07:42:13'),
(319, 'error', 'customerpage', 'Falta el campo requerido: Verificar E-mail', '', -709844532, '2009-03-25 07:42:13'),
(320, 'error', 'customerpage', 'Falta el campo requerido: DirecciÃ³n', '', -709844532, '2009-03-25 07:42:13'),
(321, 'error', 'customerpage', 'Falta el campo requerido: Ciudad', '', -709844532, '2009-03-25 07:42:13'),
(322, 'error', 'customerpage', 'Falta el campo requerido: Estado/Provincia', '', -709844532, '2009-03-25 07:42:13'),
(323, 'error', 'customerpage', 'Falta el campo requerido: CÃ³digo Postal', '', -709844532, '2009-03-25 07:42:13'),
(324, 'error', 'customerpage', 'Falta el campo requerido: TelÃ©fonp', '', -709844532, '2009-03-25 07:42:13'),
(325, 'error', 'customerpage', 'Falta el campo requerido: Nombre de usuario', '', -709844532, '2009-03-25 07:42:13'),
(326, 'error', 'customerpage', 'Falta el campo requerido: ContraseÃ±a', '', -709844532, '2009-03-25 07:42:13'),
(327, 'error', 'customerpage', 'Falta el campo requerido: Verificar ContraseÃ±a', '', -709844532, '2009-03-25 07:42:13'),
(328, 'error', 'customerloginpage', 'El lÃ­mite de tamaÃ±o (10) fuÃ© superado para el campo: Nombre de usuario', '', 1371065056, '2009-07-03 15:55:14'),
(329, 'error', 'customerloginpage', 'El lÃ­mite de tamaÃ±o (10) fuÃ© superado para el campo: Nombre de usuario', '', 1371065056, '2009-07-03 15:55:50'),
(330, 'error', 'customerloginpage', 'Falta el campo requerido: ContraseÃ±a', '', 1371065056, '2009-07-03 15:55:50'),
(331, 'error', 'customerloginpage', 'El lÃ­mite de tamaÃ±o (10) fuÃ© superado para el campo: Nombre de usuario', '', 1371065056, '2009-07-03 15:55:58'),
(332, 'error', 'customerpage', 'Falta el campo requerido: TelÃ©fonp', '', 2147483647, '2010-02-19 17:27:25'),
(333, 'error', 'customerpage', 'Falta el campo requerido: TelÃ©fonp', '', 1417354935, '2010-03-28 11:34:51'),
(334, 'error', 'customerpage', 'Falta el campo requerido: TelÃ©fonp', '', 1417354935, '2010-03-28 11:35:27'),
(335, 'error', 'customerpage', 'TelÃ©fono no vÃ¡lido para TelÃ©fono MÃ³vil.  Por favor compruebe que no hay guiones y que solo contiene dÃ­gitos numÃ©ricos.', '', 1417354935, '2010-03-28 11:35:27'),
(336, 'error', 'customerpage', 'Falta el campo requerido: TelÃ©fonp', '', 1417354935, '2010-03-28 11:36:19'),
(337, 'error', 'customerpage', 'Por favor, introduzca un valor mayor o igual que 1 para TelÃ©fono MÃ³vil (country code)', '', 1417354935, '2010-03-28 11:36:19'),
(338, 'security', 'Login', 'Login failed for admin', '', 2147483647, '2010-03-29 00:17:02'),
(339, 'error', 'loginpage', 'Login Failed', '', 2147483647, '2010-03-29 00:17:02'),
(340, 'security', 'Login', 'Login failed for admin', '', 2147483647, '2010-03-29 00:17:08'),
(341, 'error', 'loginpage', 'Login Failed', '', 2147483647, '2010-03-29 00:17:08'),
(342, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 2147483647, '2010-03-29 00:17:42'),
(343, 'critical', 'CustomerPage::init()', 'User account not found, account id = 0', 'Administrador', 2147483647, '2010-03-29 00:24:46'),
(344, 'security', 'Login', 'Login failed for admin', '', 1395369872, '2010-03-31 10:50:38'),
(345, 'error', 'loginpage', 'Login Failed', '', 1395369872, '2010-03-31 10:50:38'),
(346, 'security', 'Login', 'Login failed for admin', '', 1395369872, '2010-03-31 10:50:42'),
(347, 'error', 'loginpage', 'Login Failed', '', 1395369872, '2010-03-31 10:50:42'),
(348, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1395369872, '2010-03-31 10:50:49'),
(349, 'security', 'Login', 'Login failed for admin', '', 2147483647, '2010-04-21 01:29:59'),
(350, 'error', 'loginpage', 'Login Failed', '', 2147483647, '2010-04-21 01:29:59'),
(351, 'security', 'Login', 'Login failed for admin', '', 2147483647, '2010-04-21 01:30:03'),
(352, 'error', 'loginpage', 'Login Failed', '', 2147483647, '2010-04-21 01:30:03'),
(353, 'security', 'Login', 'Login failed for administrador', '', 2147483647, '2010-04-21 01:30:12'),
(354, 'error', 'loginpage', 'Login Failed', '', 2147483647, '2010-04-21 01:30:12'),
(355, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 2147483647, '2010-04-21 01:30:18'),
(356, 'error', 'viewaccountpage', 'Account not found (id = )', 'Administrador', 2147483647, '2010-04-21 01:34:02'),
(357, 'critical', 'count_all_NoteDBO()', 'SELECT COUNT failure', 'Administrador', 2147483647, '2010-04-21 01:34:02'),
(358, 'error', 'viewaccountpage', 'Account not found (id = )', 'Administrador', 2147483647, '2010-04-21 01:34:50'),
(359, 'critical', 'count_all_DomainServicePurchaseDBO()', 'SELECT COUNT failure', 'Administrador', 2147483647, '2010-04-21 01:34:50'),
(360, 'notice', 'assigndomainpage', 'Domain Service Added to Account', 'Administrador', 2147483647, '2010-04-21 01:37:28'),
(361, 'notice', 'viewaccountpage', 'Removed domain: acuchilladoresvitoria.es', 'Administrador', 2147483647, '2010-04-21 01:37:32'),
(362, 'notice', 'assigndomainpage', 'Domain Service Added to Account', 'Administrador', 2147483647, '2010-04-21 01:38:03'),
(363, 'error', 'viewinvoicepage', 'Could not load Invoice! ID: ', 'Administrador', 2147483647, '2010-04-21 01:38:47'),
(364, 'critical', 'count_all_InvoiceItemDBO', 'SELECT COUNT failure', 'Administrador', 2147483647, '2010-04-21 01:38:47'),
(365, 'error', 'viewinvoicepage', 'Could not load Invoice! ID: ', 'Administrador', 2147483647, '2010-04-21 01:38:50'),
(366, 'critical', 'count_all_InvoiceItemDBO', 'SELECT COUNT failure', 'Administrador', 2147483647, '2010-04-21 01:38:50'),
(367, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 2147483647, '2010-04-21 01:40:48'),
(368, 'notice', 'deleteinvoicepage', 'Invoice (ID: 19) Deleted', 'Administrador', 2147483647, '2010-04-21 01:41:48'),
(369, 'error', 'addinvoicepage', 'Invalid date provided for Invoice Date', 'Administrador', 2147483647, '2010-04-21 01:42:07'),
(370, 'error', 'addinvoicepage', 'Invalid date provided for Inicio Periodo FacturaciÃ³n', 'Administrador', 2147483647, '2010-04-21 01:42:07'),
(371, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 2147483647, '2010-04-21 01:42:21'),
(372, 'notice', 'deleteinvoicepage', 'Invoice (ID: 20) Deleted', 'Administrador', 2147483647, '2010-04-21 02:01:28'),
(373, 'security', 'Login', 'Login failed for administrador', '', 2147483647, '2010-04-21 02:07:00'),
(374, 'error', 'loginpage', 'Login Failed', '', 2147483647, '2010-04-21 02:07:00'),
(375, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 2147483647, '2010-04-21 02:07:04'),
(376, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 2147483647, '2010-04-21 02:07:39'),
(377, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 2147483647, '2010-04-21 02:08:29'),
(378, 'notice', 'deleteinvoicepage', 'Invoice (ID: 22) Deleted', 'Administrador', 2147483647, '2010-04-21 02:08:52'),
(379, 'notice', 'deleteinvoicepage', 'Invoice (ID: 21) Deleted', 'Administrador', 2147483647, '2010-04-21 02:09:16'),
(380, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 2147483647, '2010-04-21 02:09:37'),
(381, 'notice', 'deleteinvoicepage', 'Invoice (ID: 23) Deleted', 'Administrador', 2147483647, '2010-04-21 02:09:58'),
(382, 'critical', 'smarty_form()', 'Form (search_accountdbo_table) is not configured!', '', 2147483647, '2010-04-21 02:35:57'),
(383, 'critical', 'smarty_form()', 'Form (search_accountdbo_table) is not configured!', '', 2147483647, '2010-04-21 03:02:14'),
(384, 'critical', 'smarty_form()', 'Form (search_accountdbo_table) is not configured!', '', 2147483647, '2010-04-21 03:02:18'),
(385, 'error', 'settingspage', 'ACCESS_DENIED', '', 2147483647, '2010-04-21 03:07:14'),
(386, 'error', 'settingspage', 'ACCESS_DENIED', '', 2147483647, '2010-04-21 03:07:19'),
(387, 'error', 'settingspage', 'ACCESS_DENIED', '', 2147483647, '2010-04-21 03:07:28'),
(388, 'error', 'modulespage', 'ACCESS_DENIED', '', 2147483647, '2010-04-21 03:07:33'),
(389, 'critical', 'smarty_form()', 'Form (search_accountdbo_table) is not configured!', '', 2147483647, '2010-04-21 03:07:42'),
(390, 'notice', 'Logout', 'User:  logged out', '', 2147483647, '2010-04-21 03:07:44'),
(391, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 2147483647, '2010-04-21 03:07:54'),
(392, 'critical', 'smarty_form()', 'Form (search_accountdbo_table) is not configured!', 'Administrador', 2147483647, '2010-04-21 03:07:55'),
(393, 'critical', 'smarty_form()', 'Form (search_accountdbo_table) is not configured!', 'Administrador', 2147483647, '2010-04-21 03:08:01'),
(394, 'notice', 'Logout', 'User: Administrador logged out', 'Administrador', 2147483647, '2010-04-21 03:09:04'),
(395, 'critical', 'smarty_form()', 'Form (search_accountdbo_table) is not configured!', '', 2147483647, '2010-04-21 03:09:21'),
(396, 'error', 'settingspage', 'ACCESS_DENIED', '', 2147483647, '2010-04-21 03:10:30'),
(397, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 2147483647, '2010-04-21 03:49:38'),
(398, 'notice', 'addinvoicepage', 'Invoice Created', 'Administrador', 2147483647, '2010-04-21 03:50:53'),
(399, 'notice', 'deleteinvoicepage', 'Invoice (ID: 24) Deleted', 'Administrador', 2147483647, '2010-04-21 03:51:09'),
(400, 'notice', 'Login', 'User: Administrador logged in', 'Administrador', 1396135138, '2010-04-21 10:49:58'),
(401, 'error', 'adddomainpage', 'Falta el campo requerido: Domain Name', '', 2147483647, '2011-03-07 23:29:33'),
(402, 'critical', 'adddomainpage', 'No page to jump back too!', '', 2147483647, '2011-03-07 23:29:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `master_services`
--

CREATE TABLE IF NOT EXISTS `master_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_description` varchar(100) NOT NULL DEFAULT '',
  `pricerate` float DEFAULT NULL,
  `frequency` varchar(20) NOT NULL DEFAULT '1',
  `options_table` varchar(50) DEFAULT NULL,
  `category` varchar(25) DEFAULT NULL,
  `selling_active` enum('y','n') DEFAULT 'y',
  `hide_online` enum('y','n') NOT NULL DEFAULT 'n',
  `activate_notify` varchar(32) DEFAULT NULL,
  `modify_notify` varchar(32) DEFAULT NULL,
  `shutoff_notify` varchar(32) NOT NULL DEFAULT '',
  `activation_string` varchar(254) DEFAULT NULL,
  `usage_label` varchar(32) DEFAULT NULL,
  `organization_id` int(11) NOT NULL DEFAULT '1',
  `carrier_dependent` enum('y','n') NOT NULL DEFAULT 'n',
  `support_notify` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Volcar la base de datos para la tabla `master_services`
--

INSERT INTO `master_services` (`id`, `service_description`, `pricerate`, `frequency`, `options_table`, `category`, `selling_active`, `hide_online`, `activate_notify`, `modify_notify`, `shutoff_notify`, `activation_string`, `usage_label`, `organization_id`, `carrier_dependent`, `support_notify`) VALUES
(3, 'Example Service', 19.95, '1', 'example_options', 'example', 'y', 'n', '', '', '', 'username,password', 'items', 1, 'n', ''),
(2, 'Prorate', 1, '0', 'prorate_options', 'prorate', 'y', 'y', '', '', '', NULL, NULL, 1, 'n', ''),
(1, 'Credit', -1, '0', 'credit_options', 'credit', 'y', 'y', 'admin', '', '', '', 'dollars', 1, 'n', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `enabled` enum('Yes','No') NOT NULL DEFAULT 'No',
  `type` varchar(255) NOT NULL DEFAULT '',
  `shortdescription` varchar(32) DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `module`
--

INSERT INTO `module` (`name`, `enabled`, `type`, `shortdescription`, `description`) VALUES
('authorizeaim', 'No', 'payment_gateway', 'Credit Card', 'Authorize.net Advanced Integration Method (AIM) Payment Gateway Module'),
('nullregistrar', 'Yes', 'registrar', 'Null Registrar', 'Null Registrar Module'),
('paypalwps', 'Yes', 'payment_processor', 'Paypal', 'Paypal WPS Payment Processor Module'),
('resellerclub', 'No', 'registrar', 'Reseller Club', 'Reseller Club Domain Registrar Module');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commonname` varchar(50) NOT NULL DEFAULT '',
  `modulename` varchar(50) NOT NULL DEFAULT '',
  `sortorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sortorder` (`sortorder`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `modules`
--

INSERT INTO `modules` (`id`, `commonname`, `modulename`, `sortorder`) VALUES
(1, 'Customer', 'customer', 0),
(2, 'Services', 'services', 1),
(3, 'Billing', 'billing', 2),
(4, 'Support', 'support', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulesetting`
--

CREATE TABLE IF NOT EXISTS `modulesetting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text,
  `modulename` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Volcar la base de datos para la tabla `modulesetting`
--

INSERT INTO `modulesetting` (`id`, `name`, `value`, `modulename`) VALUES
(1, 'delimiter', '|', 'authorizeaim'),
(2, 'loginid', 'login id', 'authorizeaim'),
(3, 'transactionkey', 'transaction key', 'authorizeaim'),
(4, 'url', 'https://secure.authorize.net/gateway/transact.dll', 'authorizeaim'),
(5, 'account', 'info@creacionpaginasweb.com', 'paypalwps'),
(6, 'carturl', 'https://www.paypal.es/cgi-bin/webscr', 'paypalwps'),
(7, 'idtoken', 'ngr-9L2xONaJDW8-Mvwst4D-COPvwgta4Fc1QXX1ZrxWgekD8L9PkdF2eLO', 'paypalwps'),
(8, 'paypalcurrencycode', 'EUR', 'paypalwps'),
(9, 'debug', '0', 'resellerclub'),
(10, 'defaultcustomerpassword', 'defaultpw', 'resellerclub'),
(11, 'langpref', 'en', 'resellerclub'),
(12, 'parentid', '999999998', 'resellerclub'),
(13, 'username', 'user@email.com', 'resellerclub'),
(14, 'password', 'password', 'resellerclub'),
(15, 'resellerid', '1', 'resellerclub'),
(16, 'role', 'reseller', 'resellerclub'),
(17, 'serviceurl', 'http://demo.myorderbox.com/anacreon/servlet/rpcrouter', 'resellerclub');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `module_permissions`
--

CREATE TABLE IF NOT EXISTS `module_permissions` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(30) NOT NULL DEFAULT '',
  `permission` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Volcar la base de datos para la tabla `module_permissions`
--

INSERT INTO `module_permissions` (`id`, `modulename`, `permission`, `user`) VALUES
(5, 'customer', 'f', 'users'),
(12, 'services', 'f', 'users'),
(14, 'billing', 'f', 'users'),
(8, 'support', 'f', 'users');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `note`
--

CREATE TABLE IF NOT EXISTS `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `accountid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(10) NOT NULL DEFAULT '',
  `text` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `note`
--

INSERT INTO `note` (`id`, `date`, `updated`, `accountid`, `username`, `text`) VALUES
(1, '2007-03-09 04:44:31', '2007-03-09 04:44:31', 2, 'Administra', 0x4375656e7461733a0d0a616362696c62616f3a6c6f7363686572657320696e666f406163756368696c6c61646f72657362696c62616f2e636f6d),
(2, '2007-04-20 07:14:24', '2007-04-20 07:14:24', 5, 'Administra', 0x436f6d6d656e746172696f733a20736f6d6f7320756e612062616e646120646520636f65c2a1726e657461732067616974617320792074616d626f7265732064652076616c656e63696120790d0a7175657269616d6f7320686163657220756e6120706167696e612077656220656e2076616c656e6369616e6f206d652067757374617269612071206e6f7320646965726169732069646561730d0a70756573206e6f2074656e656d6f7320636c61726f2061756e206c6f20712071756572656d6f73),
(3, '2007-04-20 07:28:53', '2007-04-20 07:28:53', 6, 'Administra', 0x436f6d6d656e746172696f733a2051756572c3ad6120696e666f726d61726d65207061726120686163657220756e612070c3a167696e612077656220706172612076656e6465722070757a7a6c65730d0a74726964696d656e73696f6e616c6573206465206d61646572612e20436f6e2062617374616e74657320666f746f73202c207065726f206e6f206d757920636f6d706c6963616461202e20),
(4, '2007-04-21 12:25:31', '2007-04-21 12:25:31', 7, 'Administra', 0x436f6d6d656e746172696f733a20736f6d6f7320756e612062616e646120646520636f65c2a1726e657461732067616974617320792074616d626f7265732064652076616c656e63696120790d0a7175657269616d6f7320686163657220756e6120706167696e612077656220656e2076616c656e6369616e6f206d652067757374617269612071206e6f7320646965726169732069646561730d0a70756573206e6f2074656e656d6f7320636c61726f2061756e206c6f20712071756572656d6f73),
(5, '2007-04-21 12:26:03', '2007-04-21 12:26:03', 7, 'Administra', 0x0d0a4275656e6173205461726465733a0d0a0d0a5061726120756e20677275706f20636f6d6f20656c207375796f206c65732070726f706f6e6472c3ad6120756e612077656220636f6e20617061727461646f732064653a0d0a2d2050726573656e74616369c3b36e0d0a2d20486973746f726961206465206c612062616e64610d0a2d20436f6d706f6e656e7465730d0a2d204e6f7469636961732f616374756163696f6e65730d0a2d20416c62756d20646520666f746f730d0a2d20466f726d756c61696f20646520636f6e746163746f0d0a0d0a54616e746f20656c20616c62756d20646520666f746f7320636f6d6f20656c20c3a1726561206465206e6f746963696173206c6f20706f6472c3ad616e2061637475616c697a61720d0a75737465646573206d69736d6f732061206d6564696461207175652073652070726f64756a6572616e206c6f73206576656e746f732e0d0a0d0a54616d6269c3a96e20736520706f6472c3ad6120696e636c75697220756e20666f726f2064652064697363757369c3b36e2070617261206861636572206c6120776562206dc3a1730d0a696e74657261637469766120636f6e20656c207669736974616e74652e20536920747576696572616e207075626c696361646f20616c67c3ba6e20646973636f2c20736520706f6472c3ad610d0a706c616e74656172206c612076656e7461206f6e2d6c696e652e0d0a0d0a45737065726f2068616265726c657320736964652064652061797564612e20536920657374616e20696e746572657361646f73206c657320706f64656d6f7320656e7669617220756e0d0a707265737570756573746f207061726120756e6120776562206465206c6173206361726163746572c3ad737469636173206d656e63696f6e616461732c20636f6e206c61730d0a6d6f64696669636163696f6e65732071756520657374696d656e206f706f7274756e61732e0d0a0d0a4174656e74616d656e74652c0d0a0d0a4a75616e204a657375730d0a477275706f20437265616369c3b36e0d0a687474703a2f2f7777772e6372656163696f6e706167696e61737765622e636f6d2f0d0a);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `options_urls`
--

CREATE TABLE IF NOT EXISTS `options_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `urlname` varchar(25) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `options_urls`
--

INSERT INTO `options_urls` (`id`, `urlname`, `fieldname`, `url`) VALUES
(1, 'finger', 'username', 'http://www.example.com/finger.cgi?%s1%');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `datecreated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datecompleted` datetime DEFAULT NULL,
  `datefulfilled` datetime DEFAULT NULL,
  `remoteip` int(11) NOT NULL DEFAULT '0',
  `businessname` varchar(255) NOT NULL DEFAULT '',
  `contactname` varchar(255) NOT NULL DEFAULT '',
  `contactemail` varchar(255) NOT NULL DEFAULT '',
  `address1` varchar(255) NOT NULL DEFAULT '',
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `country` char(3) NOT NULL DEFAULT '',
  `postalcode` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `mobilephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `username` varchar(10) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `status` enum('Incomplete','Pending','Fulfilled') NOT NULL DEFAULT 'Incomplete',
  `accountid` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `order`
--

INSERT INTO `order` (`id`, `datecreated`, `datecompleted`, `datefulfilled`, `remoteip`, `businessname`, `contactname`, `contactemail`, `address1`, `address2`, `city`, `state`, `country`, `postalcode`, `phone`, `mobilephone`, `fax`, `username`, `password`, `status`, `accountid`) VALUES
(1, '2007-03-09 09:18:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1042676305, '', 'usuario de prueba', 'info@creacionpaginasweb.com', 'aqui', '', 'kkkkk', 'jjjjj', 'VU', '908989', '99-8898-89898', '', '', 'usuario', 'usuarioguay', 'Incomplete', 0),
(4, '2007-03-12 00:59:06', '2007-03-12 00:59:04', '0000-00-00 00:00:00', 1473830506, 'Empresa de ejemplo', 'mi nombre', 'info@creacionpaginasweb.com', 'borrame s/n', '', 'Barcelona', 'Barcelona', 'ES', '8080', '34-945-1212121', '', '', 'borrame', 'borrame', 'Pending', 0),
(3, '2007-03-11 13:26:55', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1042676305, 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'info@creacionpaginasweb.com', 'ES', '1212', '34-333-333333', '', '', 'prueba', 'prueba', 'Incomplete', 0),
(5, '2007-06-01 08:33:22', '2007-06-01 08:33:22', '0000-00-00 00:00:00', 1473830506, '', 'Keys', 'keys.plus@gmail.com', 'Plus s/n', '', 'Ninguna', 'Provincia', 'ES', '8080', '34-123-456789', '', '', 'keysplus', 'pacoporras', 'Pending', 0),
(6, '2007-10-22 23:31:05', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1473830506, 'Mi Empresa', 'Mi Nombre', 'sistemas@webhouse.es', 'Mi direcciÃ³n', '', 'Mi Ciudad', 'Mi Provincia', 'ES', '0', '34-91-3151212', '', '', 'usuario', 'contra', 'Incomplete', 0),
(7, '2010-02-19 17:28:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2147483647, 'dfd', 'fdfdfd', 'h@hotmail.com', 'fdf', 'dfdfdfdf', 'dfdfdf', 'dfdf', 'ES', '809', '34-809-809', '34-809-809', '34-898-898', 'dfdfdf', '123456', 'Incomplete', 0),
(8, '2010-03-28 11:37:52', '2010-03-28 11:37:52', '0000-00-00 00:00:00', 1417354935, 'SOCIEDAD VALENCIANA DE EXPLOTACIONES VARIAS SL', 'FRANCISCO SALINAS', 'gmccombustibles@gmail.com', 'GUILLEM DE ASTRO,13-4Âª', '', 'VALENCIA', 'ESPAÃ‘A', 'ES', '46007', '34-96-3510206', '', '', '19834021', '962300947', 'Pending', 0),
(9, '2010-03-29 00:26:08', '2010-03-29 00:26:08', '0000-00-00 00:00:00', 2147483647, 'dasdasda', 'sdasdasd', 'jaceved2@xtec.cat', 'asdasdasdas', 'dsdasd', 'dasdasd', 'asdasdas', 'PM', 'dasdasd', '34-323-234234234', '', '', '123123', '123123', 'Pending', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orderdomain`
--

CREATE TABLE IF NOT EXISTS `orderdomain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderid` int(10) unsigned NOT NULL DEFAULT '0',
  `orderitemid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` enum('New','Transfer','Existing') NOT NULL DEFAULT 'Existing',
  `status` enum('Rejected','Pending','Accepted','Fulfilled') NOT NULL DEFAULT 'Pending',
  `tld` varchar(255) DEFAULT NULL,
  `domainname` varchar(255) NOT NULL DEFAULT '',
  `term` enum('1 year','2 year','3 year','4 year','5 year','6 year','7 year','8 year','9 year','10 year') DEFAULT '1 year',
  `transfersecret` varchar(255) DEFAULT NULL,
  `admincontactid` int(10) unsigned NOT NULL,
  `billingcontactid` int(10) unsigned NOT NULL,
  `techcontactid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `orderdomain`
--

INSERT INTO `orderdomain` (`id`, `orderid`, `orderitemid`, `type`, `status`, `tld`, `domainname`, `term`, `transfersecret`, `admincontactid`, `billingcontactid`, `techcontactid`) VALUES
(1, 0, 0, 'Existing', 'Pending', '', 'mariposasnegras.com', '', '', 0, 0, 0),
(2, 3, 0, 'New', 'Pending', 'com', 'pepe', '1 year', '', 1, 2, 3),
(3, 4, 0, 'New', 'Pending', 'es', 'webhouse', '10 year', '', 4, 5, 6),
(4, 5, 0, 'New', 'Pending', 'com', 'papichulo', '1 year', '', 7, 8, 9),
(5, 6, 0, 'New', 'Pending', 'com', 'laspelisdelplus', '1 year', '', 10, 11, 12),
(6, 8, 0, 'New', 'Pending', 'es', 'saloter', '1 year', '', 13, 14, 15),
(7, 8, 2, 'New', 'Pending', 'com', 'bancodeiguazu', '1 year', '', 16, 17, 18),
(8, 9, 0, 'New', 'Pending', 'com', 'ggggg', '1 year', '', 19, 20, 21);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orderhosting`
--

CREATE TABLE IF NOT EXISTS `orderhosting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderid` int(10) unsigned NOT NULL DEFAULT '0',
  `orderitemid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` enum('Rejected','Pending','Accepted','Fulfilled') NOT NULL DEFAULT 'Pending',
  `serviceid` int(10) unsigned NOT NULL DEFAULT '0',
  `term` enum('1 month','3 month','6 month','12 month') NOT NULL DEFAULT '1 month',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `orderhosting`
--

INSERT INTO `orderhosting` (`id`, `orderid`, `orderitemid`, `status`, `serviceid`, `term`) VALUES
(1, 1, 0, 'Pending', 2, '6 month'),
(4, 4, 1, 'Pending', 2, '3 month'),
(3, 3, 1, 'Pending', 2, '6 month'),
(5, 5, 1, 'Pending', 1, '12 month'),
(6, 6, 1, 'Pending', 2, '12 month'),
(7, 7, 0, 'Pending', 1, '1 month'),
(8, 8, 1, 'Pending', 3, '1 month'),
(9, 9, 1, 'Pending', 1, '1 month');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) unsigned DEFAULT NULL,
  `orderid` int(10) unsigned DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `transaction1` varchar(255) DEFAULT NULL,
  `transaction2` varchar(255) DEFAULT NULL,
  `type` enum('Credit','Cash','Check','Module','Other') NOT NULL DEFAULT 'Cash',
  `module` varchar(255) DEFAULT NULL,
  `status` enum('Declined','Completed','Pending','Authorized','Refunded','Reversed','Voided') NOT NULL DEFAULT 'Completed',
  `statusmessage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `payment`
--

INSERT INTO `payment` (`id`, `invoiceid`, `orderid`, `date`, `amount`, `transaction1`, `transaction2`, `type`, `module`, `status`, `statusmessage`) VALUES
(1, 0, 2, '2007-03-10 13:15:23', 58.80, '', '', 'Check', '', 'Pending', NULL),
(2, 6, 0, '2006-06-20 00:00:01', 612.40, '', '', 'Other', '', 'Completed', NULL),
(3, 0, 4, '2007-03-12 00:59:04', 341.91, '', '', 'Check', '', 'Pending', NULL),
(4, 0, 5, '2007-06-01 08:33:22', 97.21, '', '', 'Check', '', 'Pending', NULL),
(5, 0, 8, '2010-03-28 11:37:52', 150.57, '', '', 'Check', '', 'Pending', NULL),
(6, 0, 9, '2010-03-29 00:26:08', 44.60, '', '', 'Check', '', 'Pending', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payment_history`
--

CREATE TABLE IF NOT EXISTS `payment_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creation_date` date NOT NULL DEFAULT '0000-00-00',
  `transaction_code` varchar(32) DEFAULT NULL,
  `billing_id` int(11) NOT NULL DEFAULT '0',
  `creditcard_number` varchar(16) DEFAULT NULL,
  `creditcard_expire` int(4) unsigned zerofill DEFAULT NULL,
  `billing_amount` decimal(9,2) DEFAULT NULL,
  `response_code` varchar(100) DEFAULT NULL,
  `paid_from` date NOT NULL DEFAULT '0000-00-00',
  `paid_to` date NOT NULL DEFAULT '0000-00-00',
  `invoice_number` int(128) DEFAULT NULL,
  `status` set('authorized','declined','pending','donotreactivate','collections','turnedoff','credit','canceled','cancelwfee','pastdue','noticesent','waiting') DEFAULT NULL,
  `payment_type` set('creditcard','check','cash','eft','nsf','discount') DEFAULT NULL,
  `check_number` varchar(32) DEFAULT NULL,
  `avs_response` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `payment_history`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` blob,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `taxable` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `product`
--

INSERT INTO `product` (`id`, `name`, `description`, `price`, `taxable`) VALUES
(1, 'DiseÃ±o BÃ¡sico', 0x44697365c3b16f20646520342070c3a167696e617320657374c3ad746963617320636f6e20756e20666f726d756c6172696f20646520636f6e746163746f2e, 250.00, 'Yes'),
(2, 'Comercio ElectrÃ³nico', 0x44697365c3b16f20792070756573746120656e206d617263686120646520756e61207469656e6461207669727475616c2e20496e636c757479652064697365c3b16f20332070c3a167696e61732e, 618.75, 'Yes'),
(3, 'Instalaci&oacute;n de script', 0x466f726f732c20636861742c206574632e, 200.00, 'Yes'),
(4, 'DiseÃ±o PÃ¡gina adicional', '', 31.25, 'Yes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productprice`
--

CREATE TABLE IF NOT EXISTS `productprice` (
  `productid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` enum('Onetime','Recurring') NOT NULL DEFAULT 'Onetime',
  `termlength` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(20,2) NOT NULL DEFAULT '0.00',
  `taxable` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`productid`,`type`,`termlength`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `productprice`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productpurchase`
--

CREATE TABLE IF NOT EXISTS `productpurchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productid` int(11) NOT NULL DEFAULT '0',
  `accountid` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `productpurchase`
--

INSERT INTO `productpurchase` (`id`, `productid`, `accountid`, `date`, `note`) VALUES
(1, 1, 4, '2007-03-31 00:00:01', ''),
(3, 3, 4, '2007-03-31 00:00:01', 'Sofware de gestiÃ³n de noticias'),
(5, 3, 4, '2007-03-31 00:00:01', 'Software galerÃ­a de fotos'),
(6, 2, 6, '2007-04-20 00:00:01', ''),
(7, 1, 7, '2007-04-21 00:00:01', ''),
(9, 4, 7, '2007-04-21 00:00:01', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prorate_options`
--

CREATE TABLE IF NOT EXISTS `prorate_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_services` int(11) NOT NULL DEFAULT '0',
  `service_description` varchar(255) DEFAULT NULL,
  `service_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `prorate_options`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `searches`
--

CREATE TABLE IF NOT EXISTS `searches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` text NOT NULL,
  `owner` varchar(32) DEFAULT NULL,
  `outputform` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Volcar la base de datos para la tabla `searches`
--

INSERT INTO `searches` (`id`, `query`, `owner`, `outputform`) VALUES
(1, 'SELECT * FROM customer WHERE account_number = %s1%', NULL, ''),
(2, '(SELECT * FROM customer WHERE name LIKE ''%%s1%%'') UNION (SELECT * FROM customer WHERE company LIKE ''%%s1%%'')', NULL, NULL),
(3, 'SELECT name,company,street,phone,account_number FROM customer WHERE phone LIKE ''%%s1%%''', NULL, NULL),
(4, 'SELECT * FROM customer c LEFT JOIN billing b on b.id = c.default_billing_id WHERE c.signup_date BETWEEN ''%s1%'' AND ''%s2%'' ORDER BY c.signup_date', NULL, NULL),
(5, 'SELECT * FROM billing WHERE id = %s1%', NULL, NULL),
(6, 'SELECT * FROM billing WHERE company LIKE ''%%s1%%''', NULL, NULL),
(7, 'SELECT * FROM billing WHERE payment_due_date = ''%%s1%%''', NULL, NULL),
(8, 'SELECT * FROM customer_history WHERE id = %s1%', NULL, NULL),
(9, 'SELECT * FROM example_options do LEFT JOIN user_services us ON us.id = do.user_services WHERE username LIKE ''%%s1%%'' ', NULL, NULL),
(10, 'SELECT * FROM example_options wo LEFT JOIN user_services us ON us.id = wo.user_services WHERE password LIKE ''%%s1%%'' ', NULL, NULL),
(11, 'SELECT * FROM example_options wo LEFT JOIN user_services us ON us.id = wo.user_services WHERE equipment LIKE ''%%s1%%'' ', NULL, NULL),
(12, 'SELECT cu.account_number, cu.name, cu.company, cu.street, cu.phone\r\nFROM customer cu WHERE cu.street LIKE ''%%s1%%''', NULL, NULL),
(13, 'SELECT bh.id AS InvoiceNumber, b.account_number, b.name, b.company FROM `billing_history` bh LEFT JOIN billing b ON bh.billing_id = b.id WHERE bh.id = ''%s1%''', NULL, NULL),
(14, 'SELECT * FROM billing WHERE contact_email LIKE ''%%s1%%''', NULL, NULL),
(15, 'SELECT b.id id, b.name, b.company, b.account_number account_number, b.next_billing_date next_billing_date, bt.name billing_type, c.cancel_date cancel_date, c.removal_date removal_date, ms.service_description service_description FROM user_services us LEFT JOIN billing b ON us.billing_id = b.id LEFT JOIN customer c ON b.account_number = c.account_number LEFT JOIN billing_types bt ON b.billing_type = bt.id LEFT JOIN master_services ms ON us.master_service_id = ms.id WHERE b.next_billing_date BETWEEN ''%s1%'' AND ''%s2%'' AND us.removed <> ''y'' AND bt.method <> ''free'' GROUP BY b.id ORDER BY b.next_billing_date', NULL, NULL),
(16, 'SELECT * FROM customer_history WHERE DATE(creation_date) = ''%s1%'' ORDER BY created_by ASC', NULL, NULL),
(17, 'SELECT * FROM customer_history WHERE created_by = ''%s1%'' ORDER BY creation_date DESC', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `server`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `setting` varchar(255) NOT NULL DEFAULT '',
  `value` text,
  PRIMARY KEY (`setting`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `settings`
--

INSERT INTO `settings` (`setting`, `value`) VALUES
('welcome_subject', 'Welcome to Web Hosting Company!'),
('welcome_email', 'This is the welcome email that can be sent to your new \r\ncustomers.'),
('invoice_text', 'Factura #{invoice_id}\r\n\r\n===================================================================\r\nConcepto                                    Precio     Cantidad  Total\r\n===================================================================\r\n{invoice_items}===================================================================\r\n\r\nSub-Total: {invoice_subtotal}\r\nIVA: {invoice_taxtotal}\r\nTotal Factura: {invoice_total}\r\nPagos Recibidos: {invoice_payments}\r\nBalance: {invoice_balance}\r\nDate Due: {invoice_due}\r\n\r\nSi tiene alguna duda sobre esta factura, contacte con info@creacionpaginasweb.com.\r\n\r\nGracias\r\n\r\nGrupo CreaciÃ³n\r\nwww.creacionpaginasweb.com\r\n'),
('payment_gateway_default_module', ''),
('payment_gateway_order_method', 'Authorize Only'),
('order_confirmation_email', '{contact_name},\r\n\r\nGracias por confiar en Grupo CreaciÃ³n:\r\n\r\nSu pedido ha sido recibido y contactaremos con usted tam pronto nuestro departamento de administraciÃ³n lo halla revisado.\r\n\r\nID del pedido: {order_id}\r\nRecibido desde: {order_ip}'),
('order_confirmation_subject', 'Gracias por su pedido'),
('order_notification_subject', 'SolidState Order Received'),
('order_notification_email', 'A new order from {contact_name} has been received.\r\n\r\nRemote IP: ({order_ip})\r\nTimestamp: {order_datestamp}'),
('invoice_subject', 'Factura de {company_name} para el periodo {period_begin_date} - {period_end_date}'),
('order_accept_checks', '1'),
('company_name', 'Grupo Creaci&oacute;n'),
('company_email', 'info@creacionpaginasweb.com'),
('company_notification_email', 'info@creacionpaginasweb.com'),
('locale_language', 'spanish'),
('locale_currency_symbol', 'â‚¬'),
('nameservers_ns1', 'ns1.creacionpaginasweb.com'),
('nameservers_ns2', 'ns2.creacionpaginasweb.com'),
('nameservers_ns3', 'ns3.creacionpaginasweb.com'),
('nameservers_ns4', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taxed_services`
--

CREATE TABLE IF NOT EXISTS `taxed_services` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `master_services_id` int(10) NOT NULL DEFAULT '0',
  `tax_rate_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `taxed_services`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taxrule`
--

CREATE TABLE IF NOT EXISTS `taxrule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country` char(2) NOT NULL DEFAULT '',
  `state` varchar(255) DEFAULT NULL,
  `rate` decimal(4,2) NOT NULL DEFAULT '0.00',
  `allstates` enum('Yes','Specific') NOT NULL DEFAULT 'Yes',
  `description` varchar(255) NOT NULL DEFAULT 'Tax',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `taxrule`
--

INSERT INTO `taxrule` (`id`, `country`, `state`, `rate`, `allstates`, `description`) VALUES
(1, 'ES', '', 16.00, 'Yes', 'IVA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tax_rates`
--

CREATE TABLE IF NOT EXISTS `tax_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL DEFAULT '',
  `rate` float NOT NULL DEFAULT '0',
  `if_field` varchar(30) DEFAULT NULL,
  `if_value` varchar(30) DEFAULT NULL,
  `percentage_or_fixed` enum('percentage','fixed') NOT NULL DEFAULT 'percentage',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Volcar la base de datos para la tabla `tax_rates`
--

INSERT INTO `tax_rates` (`id`, `description`, `rate`, `if_field`, `if_value`, `percentage_or_fixed`) VALUES
(1, 'Federal Telephone Excise Tax', 0.03, '', '', 'percentage'),
(3, 'Alabama Sales Tax', 0.04, 'state', 'AL', 'percentage'),
(4, 'Arizona Sales Tax', 0.056, 'state', 'AZ', 'percentage'),
(5, 'Arkansas Sales Tax', 0.05125, 'state', 'AR', 'percentage'),
(6, 'California Sales Tax', 0.0725, 'state', 'CA', 'percentage'),
(7, 'Colorado Sales Tax', 0.029, 'state', 'CO', 'percentage'),
(8, 'Connecticut Sales Tax', 0.06, 'state', 'CT', 'percentage'),
(9, 'Florida Sales Tax', 0.06, 'state', 'FL', 'percentage'),
(10, 'Georgia Sales Tax', 0.04, 'state', 'GA', 'percentage'),
(11, 'Hawaii Sales Tax', 0.04, 'state', 'HI', 'percentage'),
(12, 'Idaho Sales Tax', 0.06, 'state', 'ID', 'percentage'),
(13, 'Illinois Sales Tax', 0.0625, 'state', 'IL', 'percentage'),
(14, 'Indiana Sales Tax', 0.06, 'state', 'IN', 'percentage'),
(15, 'Iowa Sales Tax', 0.05, 'state', 'IA', 'percentage'),
(16, 'Kansas Sales Tax', 0.053, 'state', 'KS', 'percentage'),
(17, 'Kentucky Sales Tax', 0.06, 'state', 'KY', 'percentage'),
(18, 'Louisiana Sales Tax', 0.04, 'state', 'LA', 'percentage'),
(19, 'Maine Sales Tax', 0.05, 'state', 'ME', 'percentage'),
(20, 'Massachusetts Sales Tax', 0.05, 'state', 'MA', 'percentage'),
(21, 'Michigan Sales Tax', 0.06, 'state', 'MI', 'percentage'),
(22, 'Minnesota Sales Tax', 0.065, 'state', 'MN', 'percentage'),
(23, 'Mississippi Sales Tax', 0.07, 'state', 'MS', 'percentage'),
(24, 'Missouri Sales Tax', 0.04225, 'state', 'MO', 'percentage'),
(25, 'Nebraska Sales Tax', 0.055, 'state', 'NE', 'percentage'),
(26, 'Nevada Sales Tax', 0.065, 'state', 'NV', 'percentage'),
(27, 'New Jersey Sales Tax', 0.06, 'state', 'NJ', 'percentage'),
(28, 'New Mexico Sales Tax', 0.05, 'state', 'NM', 'percentage'),
(29, 'New York Sales Tax', 0.0425, 'state', 'NY', 'percentage'),
(30, 'North Carolina Sales Tax', 0.045, 'state', 'NC', 'percentage'),
(31, 'North Dakota Sales Tax', 0.05, 'state', 'ND', 'percentage'),
(32, 'Ohio Sales Tax', 0.06, 'state', 'OH', 'percentage'),
(33, 'Oklahoma Sales Tax', 0.045, 'state', 'OK', 'percentage'),
(34, 'Pennsylvania Sales Tax', 0.06, 'state', 'PA', 'percentage'),
(35, 'Rhode Island Sales Tax', 0.07, 'state', 'RI', 'percentage'),
(36, 'South Carolina Sales Tax', 0.05, 'state', 'SC', 'percentage'),
(37, 'South Dakota Sales Tax', 0.04, 'state', 'SD', 'percentage'),
(38, 'Tennessee Sales Tax', 0.07, 'state', 'TN', 'percentage'),
(39, 'Texas Sales Tax', 0.0625, 'state', 'TX', 'percentage'),
(40, 'Utah Sales Tax', 0.0475, 'state', 'UT', 'percentage'),
(41, 'Vermont Sales Tax', 0.06, 'state', 'VT', 'percentage'),
(42, 'Virginia Sales Tax', 0.045, 'state', 'VA', 'percentage'),
(43, 'Washington Sales Tax', 0.065, 'state', 'WA', 'percentage'),
(44, 'West Virginia Sales Tax', 0.06, 'state', 'WV', 'percentage'),
(45, 'Wisconsin Sales Tax', 0.05, 'state', 'WI', 'percentage'),
(46, 'Wyoming Sales Tax', 0.04, 'state', 'WY', 'percentage'),
(47, 'District of Columbia Sales Tax', 0.0575, 'state', 'DC', 'percentage');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(32) NOT NULL,
  `accountid` int(10) unsigned DEFAULT NULL,
  `password` varchar(32) NOT NULL DEFAULT '',
  `type` enum('Account Manager','Administrator','Client') NOT NULL DEFAULT 'Client',
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `user`
--

INSERT INTO `user` (`username`, `accountid`, `password`, `type`, `firstname`, `lastname`, `email`, `language`) VALUES
('Administrador', 0, '0a56d79b83dcc7b96430c0e2fd330c7e', 'Administrator', 'Juan Jesus', 'Acevedo', 'info@creacionpaginasweb.com', 'spanish');
